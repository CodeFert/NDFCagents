"""Offline tests — no DrChrono or Claude calls. Run: pytest -q"""
import os
from pathlib import Path

os.environ.setdefault("CONFIG_DIR", str(Path(__file__).parents[1] / "config"))

from app import notes  # noqa: E402
from app.agents import history_intake as hi  # noqa: E402
from app.agents import pertinent_history as ph  # noqa: E402

# ---------------------------------------------------------------- notes section
def test_notes_sections_preserve_staff_text():
    n = notes.upsert_section("Pt running late", "NDFC-HISTORY", "34yo")
    n = notes.upsert_section(n, "NDFC-PAYMENT", "Copay $40")
    n = notes.upsert_section(n, "NDFC-HISTORY", "35yo")
    assert n.startswith("Pt running late")
    assert notes.get_section(n, "NDFC-HISTORY") == "35yo"
    assert notes.get_section(n, "NDFC-PAYMENT") == "Copay $40"
    assert n.count("[[NDFC-HISTORY]]") == 1


# ---------------------------------------------------------------- pertinent history
def test_summary_number_check_blocks_invented_values():
    f = {"age": 34, "labs": [{"test": "AMH", "value": "1.2", "unit": "ng/mL", "date": "2026-08-01"}]}
    assert ph.verify(["34yo, AMH 1.2 ng/mL (2026-08-01)"], f)
    assert not ph.verify(["34yo, AMH 2.1 ng/mL"], f)


def test_template_fallback_has_allergy_line():
    lines = ph.template({"visit_type": "Follow Up", "age": 34, "sex": "Female", "allergies": []})
    assert "Allergies: NKDA" in lines


# ---------------------------------------------------------------- history intake
class FakeChart:
    pid = 101
    patient = {"first_name": "Jane", "last_name": "Doe", "date_of_birth": "1990-05-02",
               "custom_demographics": [{"field_type": 1, "value": "2"}]}
    problems = [{"name": "PCOS"}]
    medications = [{"name": "Letrozole 2.5 mg"}]
    allergies = []


def X(v, c="high", p=1):
    return {"value": v, "confidence": c, "page": p}


def test_identity_check():
    ok, _ = hi.identity_matches({"patient_name": X("Jane A. Doe"), "date_of_birth": X("1990-05-02")}, FakeChart.patient)
    bad, why = hi.identity_matches({"patient_name": X("Jane Doe"), "date_of_birth": X("1990-02-05")}, FakeChart.patient)
    assert ok and not bad and "DOB" in why


def test_plan_writes_dedupes_gates_confidence_and_keeps_existing_custom_values():
    extracted = {
        "medical_history": [{"name": "PCOS", "confidence": "high"}, {"name": "Hypothyroidism", "confidence": "high"},
                            {"name": "Endometriosis?", "confidence": "low", "page": 2}],
        "medications": [{"name": "Letrozole", "confidence": "high"}, {"name": "Levothyroxine", "dose": "50 mcg",
                                                                       "frequency": "daily", "confidence": "high"}],
        "allergies": [{"substance": "Penicillin", "reaction": "hives", "confidence": "high"}],
        "gravida": X(3), "para": X(1),
    }
    names = {1: "Gravida", 2: "Para"}
    writes, review = hi.plan_writes(extracted, FakeChart, hi.load_map(), names)
    paths = [(m, p, b.get("name") or b.get("description")) for m, p, b in writes]
    assert ("POST", "/api/problems", "Hypothyroidism") in paths
    assert ("POST", "/api/problems", "PCOS") not in paths              # already on chart
    assert ("POST", "/api/medications", "Levothyroxine") in paths
    assert not any(n == "Letrozole" for _, _, n in paths)              # already on chart
    assert ("POST", "/api/allergies", "Penicillin") in paths
    patch = [b for m, p, b in writes if m == "PATCH"][0]["custom_demographics"]
    assert {"field_type": 1, "value": "2"} in patch                    # existing Gravida kept, not overwritten
    assert {"field_type": 2, "value": "1"} in patch                    # Para added
    fields = {r["field"] for r in review}
    assert "medical_history" in fields                                 # low-confidence item queued
    assert "Gravida" in fields                                         # conflict with existing value queued
