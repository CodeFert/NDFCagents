"""Fee schedule rules, using de-identified versions of the cases billing walked through on 10/07/2026."""
import os
from pathlib import Path

os.environ.setdefault("CONFIG_DIR", str(Path(__file__).parents[1] / "config"))

from app.agents import fee_rules as fr  # noqa: E402
from app.agents import fee_schedule as fs  # noqa: E402

RULES, PRICES = fs.load_rules(), fs.load_prices()


def appt(reason, time="08:00", notes="", virtual=False, profile=""):
    return {"id": 1, "time": time, "reason": reason, "profile": profile, "notes": notes, "virtual": virtual}


def case(**kw):
    base = {"coverage_tier": "diagnostic", "not_contracted": False, "military": False, "insurance_on_file": True,
            "copay": 0, "treatment_type": "none", "treatment_self_pay": False, "amount_paid_toward_cycle": 0,
            "package_paid": False, "uncertain": [], "new_patient": False, "balance_due": None}
    base.update(kw)
    return base


def d(a, c):
    return fr.decide(a, c, PRICES, RULES)


# --- no-cost visits
def test_outside_monitoring_is_dashes():
    assert d(appt("Outside Monitoring for FET: SHG DUE", "07:00"), case()).status == fr.DASHES


def test_complimentary_730_scan():
    assert d(appt("IVF Follicle Tracking", "07:30"), case(coverage_tier="cash")).outcome == "NO_COST"


# --- self-pay IVF package (diagnostic-only patient doing IVF)
def test_ivf_paid_in_full_with_icsi_is_dashes():
    c = case(treatment_type="ivf", treatment_self_pay=True, consent_icsi=True, consent_pgt="none",
             amount_paid_toward_cycle=7600)
    r = d(appt("IVF Follicle Tracking"), c)
    assert r.outcome == "NO_COST" and r.status == fr.DASHES


def test_ivf_pgt_a_unpaid_lists_items_and_deposit():
    # IVF $6500 + Anes $500 + Biopsy $1200 + PGT-A $2000 = $10,200 ; deposit $500
    c = case(treatment_type="ivf", treatment_self_pay=True, consent_icsi=False, consent_pgt="pgt_a",
             amount_paid_toward_cycle=500, loan_status="pending")
    r = d(appt("IVF Follicle Tracking"), c)
    assert r.outcome == "CYCLE_DUE"
    assert "IVF $6,500" in r.status and "PGT-A $2,000" in r.status and "Biopsy $1,200" in r.status
    assert "w/deposit $500 - due $9,700" in r.status
    assert r.force_review and "loan" in r.status


def test_pgt_a_already_paid_within_year_not_charged_again():
    c = case(treatment_type="ivf", treatment_self_pay=True, consent_icsi=True, consent_pgt="pgt_a",
             pgt_a_paid_within_year=True, amount_paid_toward_cycle=7600)
    assert d(appt("IVF Follicle Tracking"), c).outcome == "NO_COST"


def test_unlimited_donor_fet_package():
    c = case(treatment_type="donor_fet", treatment_self_pay=True, unlimited_transfer_package=True)
    assert d(appt("Embryo Transfer"), c).status == fr.DASHES


def test_second_transfer_after_ivf_goes_to_billing():
    c = case(treatment_type="ivf", treatment_self_pay=True, package_paid=True, transfers_since_retrieval=1)
    assert d(appt("Endometrial Lining Check"), c).outcome == "NEEDS_REVIEW"


# --- insured
def test_insured_fet_estimate_unpaid():
    c = case(coverage_tier="dx_iui_ivf", treatment_type="fet", estimate_amount=2294.24, estimate_paid=False)
    assert d(appt("Endometrial Lining Check"), c).status == "FET Est $2,294.24 due"


def test_insured_fet_estimate_paid_is_sub_ins():
    c = case(coverage_tier="dx_iui_ivf", treatment_type="fet", estimate_amount=2000, estimate_paid=True, copay=0)
    assert d(appt("Embryo Transfer"), c).status == "Sub Ins"


def test_specialty_program_sub_ins():
    c = case(coverage_tier="specialty", specialty_program="Progyny", treatment_type="ivf")
    assert d(appt("Down Regulation IVF"), c).status == "Sub Ins"


def test_ocp_start_not_in_package_copay():
    c = case(coverage_tier="diagnostic", copay=40, treatment_type="ivf", treatment_self_pay=True)
    assert d(appt("OCP Start FET"), c).status == "Copay $40"


def test_telemed_followup_call_to_collect():
    r = d(appt("FU to discuss next steps", virtual=True), case(copay=15))
    assert r.status == "Call to collect Copay $15"


def test_early_pregnancy_medical_coverage_copay():
    assert d(appt("Evaluate early pregnancy"), case(coverage_tier="medical", copay=65)).status == "Copay $65"


def test_blood_draw_with_send_outs():
    r = d(appt("Blood Draw", notes="offer GCS, AMH, FSH, E2, LH, P4, PRL, CBC, TSH, HIV"), case())
    assert r.status == "Sub Ins & 3rd Party"


def test_military_iui_insemination_self_pay_and_paid():
    c = case(coverage_tier="diagnostic", military=True, treatment_type="iui", insemination_paid=True, copay=30)
    assert d(appt("IUI Follicle Tracking"), c).status == "Copay $30"
    assert d(appt("IUI"), c).outcome == "NO_COST"


# --- cash / no insurance
def test_not_contracted_cyst_check_and_labs_combined():
    c = case(coverage_tier="dx_iui_ivf", not_contracted=True)
    dets = [(a, d(a, c)) for a in (appt("Cyst Check"), appt("Blood Draw", notes="LH, E2, P4"))]
    fr.combine_patient(dets)
    assert dets[0][1].status == "US $250, Labs (LH, E2, P4) $150 - total $400"
    assert dets[1][1].status == "see above"


def test_no_insurance_found_semen_analysis_and_id_labs():
    c = case(coverage_tier="unknown", insurance_on_file=False, new_patient=True)
    dets = [(a, d(a, c)) for a in (appt("Semen Analysis"), appt("Blood Draw", notes="ID LABS...CMSFD"))]
    fr.combine_patient(dets)
    assert dets[0][1].status == "No Ins? SA $200, ID labs $250 - total $450"
    assert "blue" in dets[0][1].boxes and dets[0][1].force_review


def test_cash_new_patient_telemed_consult():
    r = d(appt("New Patient Consult", virtual=True), case(coverage_tier="cash"))
    assert r.status == "Call to collect NP consult $250" and "blue" not in r.boxes


def test_comp_followup_after_cycle():
    assert d(appt("follow up consult"), case(coverage_tier="cash", comp_followup_eligible=True)).outcome == "NO_COST"


# --- markers & safety
def test_shg_needs_consent_red_box():
    assert "red" in d(appt("Uterine cavity assessment"), case(procedure_consent_signed=False)).boxes


def test_unsigned_price_sheet_green_box():
    c = case(treatment_type="ivf", treatment_self_pay=True, price_sheet_signed=False, amount_paid_toward_cycle=7000)
    assert "green" in d(appt("Down Regulation IVF"), c).boxes


def test_balance_and_uncertainty_force_review():
    assert d(appt("Follow Up"), case(balance_due=86.78)).force_review
    assert d(appt("IVF Follicle Tracking"), case(uncertain=["switched IUI to IVF"])).force_review


def test_expired_authorization_flagged():
    c = case(coverage_tier="dx_iui_ivf", treatment_type="fet", authorization_status="mismatch", copay=0)
    assert d(appt("Endometrial Lining Check"), c).force_review


def test_unrecognized_visit():
    assert d(appt("Something new"), case()).outcome == "NEEDS_REVIEW"


def test_monitoring_labs_follow_package():
    c = case(treatment_type="ivf", treatment_self_pay=True, consent_icsi=True, consent_pgt="none",
             amount_paid_toward_cycle=7600, new_patient=True)
    dets = [(a, d(a, c)) for a in (appt("IVF Follicle Tracking"), appt("Blood Draw", notes="IVF E2...HSMA"))]
    fr.combine_patient(dets, c)
    assert [x.status for _, x in dets] == [fr.DASHES, fr.DASHES]
    assert "blue" in dets[0][1].boxes and "blue" not in dets[1][1].boxes
