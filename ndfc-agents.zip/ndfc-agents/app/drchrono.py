"""DrChrono API client.

Lessons carried over from drchrono-uploader v2:
  * ONE lock around token refresh, so concurrent jobs never race the refresh token.
  * A global throttle + backoff on 429/5xx instead of unbounded parallel calls.
  * Every write goes through `write()`, which honours DRY_RUN and records an audit row
    (endpoint, payload, created id) so any agent change can be found and reversed.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any, Iterator

import httpx

from .settings import settings

log = logging.getLogger("drchrono")


class DrChronoError(RuntimeError):
    pass


class DrChrono:
    def __init__(self, audit=None, http: httpx.Client | None = None):
        self.base = settings.drchrono_base.rstrip("/")
        self.http = http or httpx.Client(timeout=60)
        self._token_lock = threading.Lock()
        self._throttle_lock = threading.Lock()
        self._last_call = 0.0
        self._audit = audit  # callable(agent, method, path, payload, response_id, dry_run)

    # ------------------------------------------------------------------ auth
    def _load_token(self) -> dict:
        try:
            return json.loads(settings.token_file.read_text())
        except FileNotFoundError as e:
            raise DrChronoError(
                f"No token at {settings.token_file}. Run `python -m app.cli auth` once to authorize."
            ) from e

    def _save_token(self, tok: dict) -> None:
        tok["expires_at"] = time.time() + int(tok.get("expires_in", 7200)) - 120
        tmp = settings.token_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(tok))
        tmp.replace(settings.token_file)

    def _access_token(self) -> str:
        with self._token_lock:
            tok = self._load_token()
            if time.time() < tok.get("expires_at", 0):
                return tok["access_token"]
            r = self.http.post(
                f"{self.base}/o/token/",
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": tok["refresh_token"],
                    "client_id": settings.drchrono_client_id,
                    "client_secret": settings.drchrono_client_secret,
                },
            )
            if r.status_code != 200:
                raise DrChronoError(f"Token refresh failed: {r.status_code} {r.text[:200]}")
            new = r.json()
            self._save_token(new)
            return new["access_token"]

    # --------------------------------------------------------------- request
    def _throttle(self) -> None:
        with self._throttle_lock:
            gap = 1.0 / max(settings.drchrono_rps, 0.1)
            wait = self._last_call + gap - time.time()
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.time()

    def request(self, method: str, path_or_url: str, **kw) -> httpx.Response:
        url = path_or_url if path_or_url.startswith("http") else f"{self.base}{path_or_url}"
        extra_headers = kw.pop("headers", {})
        for attempt in range(6):
            self._throttle()
            headers = extra_headers | {"Authorization": f"Bearer {self._access_token()}"}
            r = self.http.request(method, url, headers=headers, **kw)
            if r.status_code == 401 and attempt == 0:
                # token revoked/expired early: force refresh once
                with self._token_lock:
                    tok = self._load_token()
                    tok["expires_at"] = 0
                    settings.token_file.write_text(json.dumps(tok))
                continue
            if r.status_code == 429 or r.status_code >= 500:
                delay = float(r.headers.get("Retry-After", 2 ** attempt))
                log.warning("DrChrono %s on %s %s, retrying in %.0fs", r.status_code, method, url, delay)
                time.sleep(delay)
                continue
            if r.status_code == 403:
                raise DrChronoError(
                    f"403 on {method} {path_or_url} — the DrChrono app is missing the scope for this "
                    "endpoint. See README 'Required scopes'."
                )
            if r.status_code >= 400:
                raise DrChronoError(f"{r.status_code} on {method} {path_or_url}: {r.text[:300]}")
            return r
        raise DrChronoError(f"Gave up on {method} {path_or_url} after retries")

    # ----------------------------------------------------------------- reads
    def get(self, path: str, **params) -> dict:
        return self.request("GET", path, params=params).json()

    def iterate(self, path: str, **params) -> Iterator[dict]:
        """Follow DrChrono's `next` pagination."""
        data = self.request("GET", path, params=params).json()
        while True:
            yield from data.get("results", [])
            nxt = data.get("next")
            if not nxt:
                return
            data = self.request("GET", nxt).json()

    def list(self, path: str, **params) -> list[dict]:
        return list(self.iterate(path, **params))

    def download(self, url: str) -> bytes:
        # Document `document` fields are pre-signed URLs; no auth header needed, but harmless.
        r = self.http.get(url, timeout=120)
        r.raise_for_status()
        return r.content

    # ---------------------------------------------------------------- writes
    def write(self, agent: str, method: str, path: str, payload: dict) -> dict:
        if settings.dry_run:
            log.info("[DRY_RUN] %s %s %s", method, path, list(payload))
            if self._audit:
                self._audit(agent, method, path, payload, None, True)
            return {"id": None, "dry_run": True}
        r = self.request(method, path, json=payload)
        body = r.json() if r.content else {}
        if self._audit:
            self._audit(agent, method, path, payload, body.get("id"), False)
        return body

    # ------------------------------------------------------- convenience API
    def appointments_on(self, day: str) -> list[dict]:
        appts = self.list("/api/appointments", date=day, verbose="true")
        if settings.office_ids:
            appts = [a for a in appts if a.get("office") in settings.office_ids]
        # drop cancelled / no-show / breaks (no patient)
        return [a for a in appts if a.get("patient") and a.get("status") not in ("Cancelled", "No Show")]

    def patient(self, pid: int) -> dict:
        return self.get(f"/api/patients/{pid}")

    def problems(self, pid: int) -> list[dict]:
        return self.list("/api/problems", patient=pid)

    def medications(self, pid: int) -> list[dict]:
        return self.list("/api/medications", patient=pid)

    def allergies(self, pid: int) -> list[dict]:
        return self.list("/api/allergies", patient=pid)

    def lab_results(self, pid: int, since: str | None = None) -> list[dict]:
        p = {"patient": pid}
        if since:
            p["since"] = since
        return self.list("/api/lab_results", **p)

    def appointments_for_patient(self, pid: int, start: str, end: str) -> list[dict]:
        return self.list("/api/appointments", patient=pid, date_range=f"{start}/{end}")

    def patient_payments(self, pid: int) -> list[dict]:
        return self.list("/api/patient_payments", patient=pid)

    def line_items(self, pid: int, since: str | None = None) -> list[dict]:
        p = {"patient": pid}
        if since:
            p["posted_date"] = since  # filter name to confirm with probe
        return self.list("/api/line_items", **p)

    def documents(self, since: str | None = None, patient: int | None = None) -> list[dict]:
        p: dict[str, Any] = {}
        if since:
            p["since"] = since
        if patient:
            p["patient"] = patient
        return self.list("/api/documents", **p)

    def clinical_notes(self, pid: int, since: str | None = None) -> list[dict]:
        p = {"patient": pid}
        if since:
            p["since"] = since
        return self.list("/api/clinical_notes", **p)
