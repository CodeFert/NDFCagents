"""Managed sections inside a DrChrono appointment's `notes` field.

Two agents write into the same notes field, and front-desk staff type there too.
Each agent owns one fenced section and only ever replaces its own section:

    <staff text stays untouched>
    [[NDFC-HISTORY]]
    ...agent text...
    [[/NDFC-HISTORY]]
"""
from __future__ import annotations

import re


def upsert_section(notes: str | None, tag: str, body: str) -> str:
    notes = notes or ""
    start, end = f"[[{tag}]]", f"[[/{tag}]]"
    block = f"{start}\n{body.strip()}\n{end}"
    pattern = re.compile(re.escape(start) + r".*?" + re.escape(end), re.S)
    if pattern.search(notes):
        return pattern.sub(lambda _: block, notes, count=1)
    return (notes.rstrip() + "\n\n" + block).strip()


def get_section(notes: str | None, tag: str) -> str | None:
    m = re.search(re.escape(f"[[{tag}]]") + r"\n?(.*?)\n?" + re.escape(f"[[/{tag}]]"), notes or "", re.S)
    return m.group(1) if m else None
