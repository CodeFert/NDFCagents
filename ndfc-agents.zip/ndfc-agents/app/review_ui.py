"""Small review web page for billing (fee schedule) and nurses (history form exceptions).

Run inside the stack on the clinic LAN only (port 8085, basic auth). Not exposed to the internet.
"""
from __future__ import annotations

import html
import secrets

from fastapi import Depends, FastAPI, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from .agents import fee_schedule
from .db import DB
from .drchrono import DrChrono
from .settings import settings

app = FastAPI(title="NDFC Agents Review")
security = HTTPBasic()
db = DB()
api = DrChrono(audit=db.audit)

NAVY, TEAL = "#1f3a5f", "#2a9d8f"   # swap for NDFC brand colors


def user(creds: HTTPBasicCredentials = Depends(security)) -> str:
    ok = settings.review_password and secrets.compare_digest(creds.username, settings.review_user) \
        and secrets.compare_digest(creds.password, settings.review_password)
    if not ok:
        raise HTTPException(401, headers={"WWW-Authenticate": "Basic"})
    return creds.username


def page(title: str, body: str) -> HTMLResponse:
    return HTMLResponse(f"""<!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
<title>{title}</title><style>
body{{font:15px system-ui;margin:0;background:#f6f7f9;color:#1b1f24}} header{{background:{NAVY};color:#fff;padding:12px 20px}}
header a{{color:#fff;margin-right:16px}} main{{padding:16px 20px;max-width:1100px}}
.card{{background:#fff;border-radius:8px;padding:14px;margin:10px 0;box-shadow:0 1px 3px #0002}}
.tag{{display:inline-block;padding:2px 8px;border-radius:10px;background:#e8eef5;font-size:12px}}
.NEEDS_REVIEW,.IDENTITY_MISMATCH{{background:#fde2e1}} .CYCLE_DUE,.ESTIMATE_DUE,.SELF_PAY{{background:#f3e5f5}} button{{background:{TEAL};color:#fff;border:0;padding:6px 12px;border-radius:5px}}
button.rej{{background:#9aa3ad}} .box{{border:2px solid;border-radius:4px;padding:1px 6px;margin-left:6px;font-size:12px}} input{{padding:5px}} q{{color:#555}} small{{color:#666}}
</style><header><b>NDFC Agents</b> &nbsp; <a href=/>Fee schedule</a><a href=/pdfs>PDFs</a><a href=/intake>History forms</a></header><main>{body}</main>""")


BOX_LABEL = {"red": "sign consent", "green": "sign price sheet", "blue": "new patient"}


def _fee_card(it: dict) -> str:
    p = it["proposal"]
    ev = "".join(f"<li><small>{html.escape(e['source'])}:</small> <q>{html.escape(e['quote'])}</q></li>"
                 for e in it["evidence"] or [])
    boxes = "".join(
        f"<label class=box style='border-color:{c}'><input type=checkbox name=box value={c} "
        f"{'checked' if c in p.get('boxes', []) else ''}> {BOX_LABEL[c]}</label>"
        for c in ("red", "green", "blue"))
    flag = "⚑ " if p.get("force_review") else ""
    return f"""<div class=card><span class="tag {p['outcome']}">{flag}{p['outcome']}</span>
<b> {html.escape(p.get('time') or '')}</b> · {html.escape(p.get('patient_name') or str(it['patient_id']))}
· {html.escape(p.get('visit') or '')} <small>appt {it['appointment_id']}</small>
<div><small>Appt notes: {html.escape(p.get('appt_notes') or '')}</small></div>
<ul>{''.join(f'<li>{html.escape(r)}</li>' for r in p['reasons'])}</ul>
{f'<details><summary>Evidence from chart</summary><ul>{ev}</ul></details>' if ev else ''}
<form method=post action=/fee/{it['id']}>
Status <input name=status value="{html.escape(p['status'])}" size=60> {boxes}<br>
<button name=action value=approve>Approve</button> <button class=rej name=action value=reject>Reject</button></form></div>"""


@app.get("/", response_class=HTMLResponse)
def fee_queue(u: str = Depends(user)):
    acc = db.accuracy(fee_schedule.AGENT)
    rate = f"{acc['rate']:.0%}" if acc["rate"] is not None else "—"
    pending = db.pending(fee_schedule.AGENT)
    parts = [f"<h2>Fee schedule review</h2><p>Accepted unchanged: <b>{rate}</b> of last {acc['reviewed']} reviewed "
             f"· mode: <b>{settings.payment_mode}</b>{' · DRY RUN' if settings.dry_run else ''} · <a href=/pdfs>PDFs</a></p>"]
    if pending:
        parts.append("<form method=post action=/fee/approve-clean><button>Approve all rows without ⚑</button> "
                     "<small>(⚑ = balance, unclear chart, authorization or loan issue — always reviewed one by one)</small></form>")
    by_office: dict[str, list] = {}
    for it in pending:
        by_office.setdefault(f"{it['visit_date']} · {it['proposal'].get('office', '')}", []).append(it)
    for office, items in by_office.items():
        parts.append(f"<h3>{html.escape(office)} <small>({len(items)})</small></h3>")
        parts += [_fee_card(it) for it in sorted(items, key=lambda i: i["proposal"].get("time") or "")]
    if not pending:
        parts.append("<p>Nothing waiting.</p>")
    return page("Fee schedule", "".join(parts))


def _post_item(it: dict, status_text: str, boxes: list[str], u: str):
    p = it["proposal"]
    edited = status_text.strip() != p["status"] or sorted(boxes) != sorted(p.get("boxes", []))
    fee_schedule.post(api, it["appointment_id"], fee_schedule.note_text(status_text.strip(), p["reasons"]) + f" — reviewed by {u}")
    db.decide(it["id"], "edited" if edited else "approved", {"status": status_text.strip(), "boxes": sorted(boxes)}, u)


@app.post("/fee/approve-clean")
def fee_approve_clean(u: str = Depends(user)):
    for it in db.pending(fee_schedule.AGENT):
        if not it["proposal"].get("force_review") and it["proposal"]["outcome"] != "NEEDS_REVIEW":
            _post_item(it, it["proposal"]["status"], it["proposal"].get("boxes", []), u)
    return RedirectResponse("/", 303)


@app.post("/fee/{item_id}")
def fee_decide(item_id: int, action: str = Form(...), status: str = Form(""), box: list[str] = Form([]),
               u: str = Depends(user)):
    it = db.get_item(item_id)
    if not it or it["status"] != "pending":
        raise HTTPException(404)
    if action == "reject":
        db.decide(item_id, "rejected", None, u)
    else:
        _post_item(it, status, box, u)
    return RedirectResponse("/", 303)


@app.get("/pdfs", response_class=HTMLResponse)
def pdf_list(u: str = Depends(user)):
    parts = ["<h2>Fee schedule PDFs</h2><p>Rebuild after reviewing so the PDFs carry the final text.</p>"]
    for day in db.visit_dates(fee_schedule.AGENT):
        files = sorted((settings.fee_pdf_dir / day).glob("*.pdf")) if (settings.fee_pdf_dir / day).exists() else []
        links = " · ".join(f"<a href='/pdfs/{day}/{f.name}'>{html.escape(f.stem.split('_', 3)[-1])}</a>" for f in files)
        parts.append(f"<div class=card><b>{day}</b> {links or '<small>not built</small>'}"
                     f"<form method=post action=/pdfs/{day} style='display:inline'> <button>Rebuild</button></form></div>")
    return page("PDFs", "".join(parts))


@app.post("/pdfs/{day}")
def pdf_build(day: str, u: str = Depends(user)):
    fee_schedule.build_pdfs(db, day)
    return RedirectResponse("/pdfs", 303)


@app.get("/pdfs/{day}/{name}")
def pdf_get(day: str, name: str, u: str = Depends(user)):
    f = (settings.fee_pdf_dir / day / name).resolve()
    if settings.fee_pdf_dir.resolve() not in f.parents or not f.exists():
        raise HTTPException(404)
    return FileResponse(f, media_type="application/pdf")


@app.get("/intake", response_class=HTMLResponse)
def intake_queue(u: str = Depends(user)):
    parts = ["<h2>History form exceptions</h2><p>Items the agent did not write (low confidence, conflicts, identity "
             "mismatch). Enter them in DrChrono yourself, then mark done.</p>"]
    for it in db.pending("history_intake"):
        p = it["proposal"]
        rows = "".join(
            f"<li><b>{html.escape(str(x['field']))}</b>: {html.escape(str(x['item']))} "
            f"<small>(conf {x.get('confidence')}, page {x.get('page')}{', ' + html.escape(x['why']) if x.get('why') else ''})</small></li>"
            for x in p.get("items", []))
        unread = "".join(f"<li>{html.escape(s)}</li>" for s in p.get("unreadable", []))
        parts.append(f"""<div class=card><span class="tag {p['outcome']}">{p['outcome']}</span>
 patient {it['patient_id']} · document {p.get('document')} · {it['visit_date']}
{f"<p>{html.escape(p['reason'])}</p>" if p.get('reason') else ''}<ul>{rows}</ul>
{f'<p>Unreadable:</p><ul>{unread}</ul>' if unread else ''}
<form method=post action=/intake/{it['id']}><button>Mark done</button></form></div>""")
    if len(parts) == 1:
        parts.append("<p>Nothing waiting.</p>")
    return page("History forms", "".join(parts))


@app.post("/intake/{item_id}")
def intake_done(item_id: int, u: str = Depends(user)):
    db.decide(item_id, "approved", None, u)
    return RedirectResponse("/intake", 303)
