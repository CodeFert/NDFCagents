"""Command line entry points.

  python -m app.cli auth                 one-time DrChrono OAuth authorization
  python -m app.cli probe [--date D]     check scopes and print real field names / profile names
  python -m app.cli fee [--date D]       run agent 1 once (default: tomorrow)
  python -m app.cli history [--date D]   run agent 2 once (default: today)
  python -m app.cli intake               run agent 3 once
  python -m app.cli schedule             run all agents on their schedules (container default)
"""
from __future__ import annotations

import argparse
import json
import logging
import time
import urllib.parse
from datetime import date, timedelta

import httpx

from .db import DB
from .drchrono import DrChrono, DrChronoError
from .settings import settings

SCOPES = ("user:read patients:read patients:write calendar:read calendar:write clinical:read clinical:write "
          "billing:read billing:patient-payment:read labs:read")


def cmd_auth(_):
    redirect = input("Redirect URI registered on your DrChrono API app: ").strip()
    url = "https://drchrono.com/o/authorize/?" + urllib.parse.urlencode(
        {"redirect_uri": redirect, "response_type": "code", "client_id": settings.drchrono_client_id, "scope": SCOPES})
    print(f"\n1. Open this URL logged in as the API user and approve:\n{url}\n")
    code = input("2. Paste the ?code= value from the redirect: ").strip()
    r = httpx.post(f"{settings.drchrono_base}/o/token/", data={
        "code": code, "grant_type": "authorization_code", "redirect_uri": redirect,
        "client_id": settings.drchrono_client_id, "client_secret": settings.drchrono_client_secret})
    r.raise_for_status()
    tok = r.json()
    tok["expires_at"] = time.time() + int(tok.get("expires_in", 7200)) - 120
    settings.token_file.write_text(json.dumps(tok))
    print(f"Saved token to {settings.token_file}. Granted scopes: {tok.get('scope')}")


def cmd_probe(args):
    """Read-only. Verifies every endpoint the agents use and prints field names to fill the YAML files."""
    api = DrChrono()
    day = args.date or (date.today() + timedelta(days=1)).isoformat()
    checks = {
        "appointment_profiles": lambda: api.list("/api/appointment_profiles"),
        "custom_demographics": lambda: api.list("/api/custom_demographics"),
        "patient_flag_types": lambda: api.list("/api/patient_flag_types"),
        "offices": lambda: api.list("/api/offices"),
        "appointments": lambda: api.appointments_on(day),
    }
    out = {}
    for name, fn in checks.items():
        try:
            out[name] = fn()
            print(f"OK   {name}: {len(out[name])}")
        except DrChronoError as e:
            print(f"FAIL {name}: {e}")
    if out.get("appointment_profiles"):
        print("\nVisit types (use these names in the YAML):")
        for p in out["appointment_profiles"]:
            print(f"  {p['id']:>8}  {p['name']}")
    if out.get("patient_flag_types"):
        print("\nPatient flag types (coverage / billing memo / cash pay flags the fee agent reads):")
        for f in out["patient_flag_types"]:
            print(f"  {f['id']:>8}  {f['name']}")
    if out.get("offices"):
        print("\nOffices (put these names in fee_schedule_rules.yaml -> offices):")
        for o in out["offices"]:
            print(f"  {o['id']:>8}  {o['name']}")
    if out.get("custom_demographics"):
        print("\nCustom demographic fields:")
        for d in out["custom_demographics"]:
            print(f"  {d['id']:>8}  {d['name']}")
    appts = out.get("appointments") or []
    if appts:
        pid = appts[0]["patient"]
        print(f"\nField names on one patient's records (patient {pid}, values hidden):")
        for label, fn in {
            "patient": lambda: [api.patient(pid)], "problems": lambda: api.problems(pid),
            "medications": lambda: api.medications(pid), "allergies": lambda: api.allergies(pid),
            "lab_results": lambda: api.lab_results(pid), "patient_payments": lambda: api.patient_payments(pid),
            "line_items": lambda: api.line_items(pid), "documents": lambda: api.documents(patient=pid),
            "insurance_authorizations": lambda: api.list("/api/insurance_authorizations", patient=pid),
        }.items():
            try:
                rows = fn()
                print(f"  {label:<25} {sorted(rows[0].keys()) if rows else '(no rows for this patient)'}")
                if label == "patient" and rows:
                    flags = rows[0].get("patient_flags")
                    print(f"  {'patient_flags shape':<25} {flags[0] if flags else '(none)'!r:.300}")
            except DrChronoError as e:
                print(f"  {label:<25} FAIL {e}")


def _run(agent_name, fn):
    db = DB()
    api = DrChrono(audit=db.audit)
    rid = db.run_start(agent_name)
    try:
        res = fn(api, db)
        db.run_end(rid, True, res)
        logging.info("%s finished: %s", agent_name, res)
        return res
    except Exception as e:
        db.run_end(rid, False, {"error": str(e)[:300]})
        logging.exception("%s failed", agent_name)


def cmd_fee(args):
    from .agents import fee_schedule
    print(_run("fee_schedule", lambda a, d: fee_schedule.run(a, d, args.date)))


def cmd_history(args):
    from .agents import pertinent_history
    print(_run("pertinent_history", lambda a, d: pertinent_history.run(a, d, args.date)))


def cmd_intake(_):
    from .agents import history_intake
    print(_run("history_intake", lambda a, d: history_intake.run(a, d)))


def cmd_schedule(_):
    from apscheduler.schedulers.blocking import BlockingScheduler
    from .agents import fee_schedule, history_intake, pertinent_history

    s = BlockingScheduler(timezone=settings.timezone)
    # 1:15 am: next day's payment status (billing reviews first thing in the morning)
    s.add_job(lambda: _run("fee_schedule", lambda a, d: fee_schedule.run(a, d)), "cron", hour=1, minute=15)
    # 4:45 am: today's pertinent histories; 11:45 am refresh catches same-day add-ons
    s.add_job(lambda: _run("pertinent_history", lambda a, d: pertinent_history.run(a, d)), "cron", hour="4,11", minute=45)
    # every 15 min during clinic hours: newly scanned history forms
    s.add_job(lambda: _run("history_intake", lambda a, d: history_intake.run(a, d)), "cron",
              day_of_week="mon-sat", hour="7-19", minute="*/15")
    logging.info("scheduler started (DRY_RUN=%s, PAYMENT_MODE=%s)", settings.dry_run, settings.payment_mode)
    s.start()


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser(prog="app.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in [("auth", cmd_auth), ("probe", cmd_probe), ("fee", cmd_fee), ("history", cmd_history),
                     ("intake", cmd_intake), ("schedule", cmd_schedule)]:
        p = sub.add_parser(name)
        p.add_argument("--date", help="YYYY-MM-DD")
        p.set_defaults(fn=fn)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
