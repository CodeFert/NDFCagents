"""Thin wrapper around the Claude API.

Every call returns *structured JSON* by forcing a single tool call with a JSON schema,
so agents never parse free text. Claude is only used where judgment over unstructured
input is needed (reading scanned forms, reading free-text notes, writing a summary);
the decisions that matter (who owes what, what gets written where) stay in code + YAML rules.

PHI goes to the Claude API: confirm your Anthropic BAA / zero-data-retention terms cover
API traffic for your Enterprise org before turning DRY_RUN off.
"""
from __future__ import annotations

import base64
import logging

import anthropic

from .settings import settings

log = logging.getLogger("llm")

_client: anthropic.Anthropic | None = None


def client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=settings.anthropic_api_key or None, max_retries=4)
    return _client


def pdf_block(pdf_bytes: bytes) -> dict:
    return {
        "type": "document",
        "source": {"type": "base64", "media_type": "application/pdf", "data": base64.b64encode(pdf_bytes).decode()},
    }


def text_block(text: str) -> dict:
    return {"type": "text", "text": text}


def structured(
    *,
    system: str,
    content: list[dict],
    schema: dict,
    tool_name: str = "submit",
    model: str | None = None,
    max_tokens: int = 4096,
) -> dict:
    """Ask Claude for output matching `schema`; returns the parsed tool input."""
    resp = client().messages.create(
        model=model or settings.claude_model,
        max_tokens=max_tokens,
        system=system,
        tools=[{"name": tool_name, "description": "Submit the result.", "input_schema": schema}],
        tool_choice={"type": "tool", "name": tool_name},
        messages=[{"role": "user", "content": content}],
    )
    for block in resp.content:
        if block.type == "tool_use" and block.name == tool_name:
            return block.input
    raise RuntimeError(f"Claude did not return a {tool_name} call (stop_reason={resp.stop_reason})")
