"""Central configuration, read from environment variables (.env in Docker)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    # --- DrChrono -----------------------------------------------------------
    drchrono_base: str = os.getenv("DRCHRONO_BASE", "https://app.drchrono.com")
    drchrono_client_id: str = os.getenv("DRCHRONO_CLIENT_ID", "")
    drchrono_client_secret: str = os.getenv("DRCHRONO_CLIENT_SECRET", "")
    # Token file is shared with nothing else: this app owns its own refresh token.
    token_file: Path = Path(os.getenv("DRCHRONO_TOKEN_FILE", "/data/drchrono_token.json"))
    default_doctor_id: int = int(os.getenv("DEFAULT_DOCTOR_ID", "60005"))
    # Max requests/second to DrChrono (stay well under their limits).
    drchrono_rps: float = float(os.getenv("DRCHRONO_RPS", "4"))

    # --- Claude -------------------------------------------------------------
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    claude_model: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
    claude_model_extraction: str = os.getenv("CLAUDE_MODEL_EXTRACTION", "claude-opus-5-5")

    # --- Behaviour ----------------------------------------------------------
    # payment agent: "review" (staff approves each one) or "auto" (posts directly)
    payment_mode: str = os.getenv("PAYMENT_MODE", "review")
    # Global kill-switch: when true nothing is ever written to DrChrono.
    dry_run: bool = _bool("DRY_RUN", True)
    timezone: str = os.getenv("TZ", "America/Phoenix")
    office_ids: list[int] = field(
        default_factory=lambda: [int(x) for x in os.getenv("OFFICE_IDS", "").split(",") if x.strip()]
    )

    # --- Paths --------------------------------------------------------------
    config_dir: Path = Path(os.getenv("CONFIG_DIR", "/app/config"))
    db_path: Path = Path(os.getenv("DB_PATH", "/data/agents.db"))
    # Per-office fee schedule PDFs land here (mount the NAS share here to drop them where staff look).
    fee_pdf_dir: Path = Path(os.getenv("FEE_PDF_DIR", "/data/fee_schedules"))

    # --- Review UI ----------------------------------------------------------
    review_user: str = os.getenv("REVIEW_USER", "billing")
    review_password: str = os.getenv("REVIEW_PASSWORD", "")


settings = Settings()
