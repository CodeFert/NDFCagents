"""Helpers for reading pieces of a DrChrono chart into plain, compact dicts."""
from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache
from typing import Any

from .drchrono import DrChrono


class Chart:
    """Lazy, cached view of one patient's chart for a single agent run."""

    def __init__(self, api: DrChrono, patient_id: int):
        self.api, self.pid = api, patient_id
        self._cache: dict[str, Any] = {}

    def _get(self, key, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    @property
    def patient(self) -> dict:
        return self._get("patient", lambda: self.api.patient(self.pid))

    @property
    def problems(self):
        return self._get("problems", lambda: self.api.problems(self.pid))

    @property
    def medications(self):
        return self._get("meds", lambda: self.api.medications(self.pid))

    @property
    def allergies(self):
        return self._get("allergies", lambda: self.api.allergies(self.pid))

    def labs(self, days: int):
        since = (date.today() - timedelta(days=days)).isoformat()
        return self._get(f"labs{days}", lambda: self.api.lab_results(self.pid, since=since))

    def appointments(self, days_back: int, days_fwd: int = 0):
        s = (date.today() - timedelta(days=days_back)).isoformat()
        e = (date.today() + timedelta(days=days_fwd)).isoformat()
        return self._get(f"appts{days_back}/{days_fwd}", lambda: self.api.appointments_for_patient(self.pid, s, e))

    @property
    def payments(self):
        return self._get("payments", lambda: self.api.patient_payments(self.pid))

    def custom_demographics(self, names: dict[int, str]) -> dict[str, str]:
        """Return {field name: value} using the practice's custom demographic definitions."""
        out = {}
        for cd in self.patient.get("custom_demographics") or []:
            name = names.get(cd.get("field_type"))
            if name:
                out[name] = cd.get("value")
        return out

    @property
    def age(self) -> int | None:
        dob = self.patient.get("date_of_birth")
        if not dob:
            return None
        y, m, d = map(int, dob.split("-"))
        t = date.today()
        return t.year - y - ((t.month, t.day) < (m, d))


@lru_cache(maxsize=1)
def _custom_demo_defs_cached(api_id: int, api: DrChrono) -> dict[int, str]:
    return {d["id"]: d["name"] for d in api.list("/api/custom_demographics")}


def custom_demographic_names(api: DrChrono) -> dict[int, str]:
    return _custom_demo_defs_cached(id(api), api)


@lru_cache(maxsize=1)
def _profiles_cached(api_id: int, api: DrChrono) -> dict[int, str]:
    return {p["id"]: p["name"] for p in api.list("/api/appointment_profiles")}


def profile_names(api: DrChrono) -> dict[int, str]:
    """appointment profile id -> visit-type name (e.g. 'IVF Monitoring')."""
    return _profiles_cached(id(api), api)
