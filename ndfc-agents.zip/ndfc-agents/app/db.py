"""SQLite store: audit log of every DrChrono write, review queue, processed documents.

Kept deliberately small. Contains PHI (patient ids + payloads), so the /data volume
must live on the encrypted server disk and be included in backups.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from typing import Any

from .settings import settings

_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY, ts TEXT, agent TEXT, method TEXT, path TEXT,
    payload TEXT, response_id TEXT, dry_run INTEGER
);
CREATE TABLE IF NOT EXISTS review_queue (
    id INTEGER PRIMARY KEY, created TEXT, agent TEXT, appointment_id INTEGER,
    patient_id INTEGER, visit_date TEXT, proposal TEXT, evidence TEXT,
    status TEXT DEFAULT 'pending',            -- pending | approved | edited | rejected | posted
    final TEXT, reviewer TEXT, reviewed TEXT,
    UNIQUE(agent, appointment_id)
);
CREATE TABLE IF NOT EXISTS processed_documents (
    document_id INTEGER PRIMARY KEY, patient_id INTEGER, processed TEXT,
    outcome TEXT, detail TEXT
);
CREATE TABLE IF NOT EXISTS doc_facts (
    document_id INTEGER PRIMARY KEY, extracted TEXT, facts TEXT
);
CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY, agent TEXT, started TEXT, finished TEXT,
    ok INTEGER, summary TEXT
);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class DB:
    def __init__(self, path=None):
        self.path = str(path or settings.db_path)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)

    def _exec(self, sql: str, args: tuple = ()) -> sqlite3.Cursor:
        with _lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    # audit -----------------------------------------------------------------
    def audit(self, agent, method, path, payload, response_id, dry_run):
        self._exec(
            "INSERT INTO audit(ts,agent,method,path,payload,response_id,dry_run) VALUES(?,?,?,?,?,?,?)",
            (_now(), agent, method, path, json.dumps(payload), str(response_id), int(dry_run)),
        )

    # review queue ----------------------------------------------------------
    def enqueue(self, agent, appointment_id, patient_id, visit_date, proposal: dict, evidence: list):
        """Insert or refresh a pending proposal. Already-reviewed rows are left alone."""
        self._exec(
            """INSERT INTO review_queue(created,agent,appointment_id,patient_id,visit_date,proposal,evidence)
               VALUES(?,?,?,?,?,?,?)
               ON CONFLICT(agent, appointment_id) DO UPDATE SET
                 proposal=excluded.proposal, evidence=excluded.evidence, created=excluded.created
               WHERE review_queue.status='pending'""",
            (_now(), agent, appointment_id, patient_id, visit_date, json.dumps(proposal), json.dumps(evidence)),
        )

    def pending(self, agent: str) -> list[dict]:
        rows = self._exec(
            "SELECT * FROM review_queue WHERE agent=? AND status='pending' ORDER BY visit_date, id", (agent,)
        ).fetchall()
        return [self._row(r) for r in rows]

    def get_item(self, item_id: int) -> dict | None:
        r = self._exec("SELECT * FROM review_queue WHERE id=?", (item_id,)).fetchone()
        return self._row(r) if r else None

    def decide(self, item_id: int, status: str, final: dict | None, reviewer: str):
        self._exec(
            "UPDATE review_queue SET status=?, final=?, reviewer=?, reviewed=? WHERE id=?",
            (status, json.dumps(final) if final else None, reviewer, _now(), item_id),
        )

    def accuracy(self, agent: str, last_n: int = 200) -> dict:
        """How often staff accepted the agent's answer unchanged — the metric for going to auto mode."""
        rows = self._exec(
            """SELECT status FROM review_queue WHERE agent=? AND status IN ('approved','edited','rejected','posted')
               ORDER BY reviewed DESC LIMIT ?""",
            (agent, last_n),
        ).fetchall()
        n = len(rows)
        ok = sum(1 for r in rows if r["status"] in ("approved", "posted"))
        return {"reviewed": n, "accepted_unchanged": ok, "rate": (ok / n) if n else None}

    @staticmethod
    def _row(r: sqlite3.Row) -> dict:
        d = dict(r)
        for k in ("proposal", "evidence", "final"):
            if d.get(k):
                d[k] = json.loads(d[k])
        return d

    def decide_by_appt(self, agent: str, appointment_id: int, status: str, final: dict | None, reviewer: str):
        self._exec(
            "UPDATE review_queue SET status=?, final=?, reviewer=?, reviewed=? WHERE agent=? AND appointment_id=?",
            (status, json.dumps(final) if final else None, reviewer, _now(), agent, appointment_id),
        )

    def day_items(self, agent: str, visit_date: str) -> list[dict]:
        rows = self._exec(
            "SELECT * FROM review_queue WHERE agent=? AND visit_date=? ORDER BY id", (agent, visit_date)
        ).fetchall()
        return [self._row(r) for r in rows]

    def visit_dates(self, agent: str, limit: int = 14) -> list[str]:
        rows = self._exec(
            "SELECT DISTINCT visit_date FROM review_queue WHERE agent=? ORDER BY visit_date DESC LIMIT ?", (agent, limit)
        ).fetchall()
        return [r[0] for r in rows]

    # document facts cache (consents / price sheets don't change once signed) ------------------
    def get_doc_facts(self, document_id: int) -> dict | None:
        r = self._exec("SELECT facts FROM doc_facts WHERE document_id=?", (document_id,)).fetchone()
        return json.loads(r[0]) if r else None

    def put_doc_facts(self, document_id: int, facts: dict):
        self._exec("INSERT OR REPLACE INTO doc_facts VALUES(?,?,?)", (document_id, _now(), json.dumps(facts)))

    # documents -------------------------------------------------------------
    def is_processed(self, document_id: int) -> bool:
        return self._exec("SELECT 1 FROM processed_documents WHERE document_id=?", (document_id,)).fetchone() is not None

    def mark_processed(self, document_id: int, patient_id: int, outcome: str, detail: Any):
        self._exec(
            "INSERT OR REPLACE INTO processed_documents VALUES(?,?,?,?,?)",
            (document_id, patient_id, _now(), outcome, json.dumps(detail)),
        )

    # runs ------------------------------------------------------------------
    def run_start(self, agent: str) -> int:
        return self._exec("INSERT INTO runs(agent,started) VALUES(?,?)", (agent, _now())).lastrowid

    def run_end(self, run_id: int, ok: bool, summary: dict):
        self._exec("UPDATE runs SET finished=?, ok=?, summary=? WHERE id=?", (_now(), int(ok), json.dumps(summary), run_id))
