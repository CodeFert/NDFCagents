"""Agent 2 — daily pertinent history in the appointment notes (no review step).

Rules decide WHAT is pulled for each visit type; Claude only condenses it.
Safety net: if the summary contains any number that is not in the gathered facts,
it is discarded and a deterministic template is written instead.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import date, datetime, timedelta

import yaml

from .. import llm
from ..chart import Chart, profile_names
from ..db import DB
from ..drchrono import DrChrono
from ..notes import upsert_section
from ..settings import settings

log = logging.getLogger("pertinent_history")
AGENT = "pertinent_history"
TAG = "NDFC-HISTORY"

SUMMARY_SCHEMA = {
    "type": "object",
    "properties": {"lines": {"type": "array", "items": {"type": "string"},
                             "description": "Short bullet lines for the physician, most important first."}},
    "required": ["lines"],
}

SYSTEM = (
    "You write a pertinent history for a reproductive endocrinologist to glance at before a visit. "
    "Use ONLY the facts provided in JSON. Do not add diagnoses, interpretations, or recommendations. "
    "Keep lab values, units and dates exactly as given. Use standard clinical abbreviations "
    "(G/P, AMH, FSH, E2, AFC, IVF, FET, IUI, NKDA). Telegraphic style, no full sentences. "
    "If a section has no data, omit it rather than saying 'none' (except allergies: say NKDA only if "
    "the allergy list is explicitly empty)."
)


def load_rules() -> dict:
    return yaml.safe_load((settings.config_dir / "pertinent_history_rules.yaml").read_text())


def rules_for(visit: str, rules: dict) -> dict:
    return {**rules["default"], **rules.get("visit_types", {}).get(visit, {})}


def _lab_row(r: dict) -> dict:
    return {
        "test": r.get("observation_description") or r.get("test_name") or r.get("description") or r.get("name"),
        "value": r.get("value"),
        "unit": r.get("value_units") or r.get("unit"),
        "flag": r.get("abnormal_status") or r.get("abnormal_flag"),
        "date": (r.get("test_performed") or r.get("collection_date") or r.get("created_at") or "")[:10],
    }


def gather(api: DrChrono, appt: dict, rules: dict) -> tuple[str, dict, dict]:
    chart = Chart(api, appt["patient"])
    profiles = profile_names(api)
    visit = profiles.get(appt.get("profile"), appt.get("reason") or "")
    r = rules_for(visit, rules)
    facts: dict = {"visit_type": visit}

    for sec in r["sections"]:
        if sec == "demographics":
            facts["age"] = chart.age
            facts["sex"] = chart.patient.get("gender")
        elif sec == "problems":
            facts["problems"] = [
                {"name": p.get("name"), "icd10": p.get("icd_code"), "since": p.get("date_diagnosis")}
                for p in chart.problems if (p.get("status") or "active").lower() == "active"
            ]
        elif sec == "medications":
            facts["medications"] = [
                " ".join(str(x) for x in (m.get("name"), m.get("dosage_quantity"), m.get("dosage_units"),
                                          m.get("frequency")) if x)
                for m in chart.medications if (m.get("status") or "active").lower() == "active"
            ]
        elif sec == "allergies":
            facts["allergies"] = [
                f"{a.get('description')} ({a.get('reaction')})" if a.get("reaction") else a.get("description")
                for a in chart.allergies if (a.get("status") or "active").lower() == "active"
            ]
        elif sec.startswith("labs:"):
            names = [n.lower() for n in rules["lab_groups"][sec.split(":", 1)[1]]]
            rows = [_lab_row(x) for x in chart.labs(r.get("lab_lookback_days", 365))]
            hit = [x for x in rows if x["test"] and any(n in x["test"].lower() for n in names)]
            hit.sort(key=lambda x: x["date"], reverse=True)
            facts.setdefault("labs", []).extend(hit[:12])
        elif sec == "recent_visits":
            past = [a for a in chart.appointments(r.get("visit_lookback_days", 90))
                    if a.get("id") != appt.get("id") and a.get("status") not in ("Cancelled", "No Show")]
            past.sort(key=lambda a: a.get("scheduled_time") or "", reverse=True)
            facts["recent_visits"] = [
                f"{(a.get('scheduled_time') or '')[:10]} {profiles.get(a.get('profile'), a.get('reason') or '')}"
                for a in past[:6]
            ]
        elif sec == "last_note":
            notes = api.clinical_notes(appt["patient"])
            notes.sort(key=lambda n: n.get("updated_at") or "", reverse=True)
            if notes:
                # clinical note text lives in clinical_note_sections; keep it short
                facts["last_note_date"] = (notes[0].get("updated_at") or "")[:10]
    return visit, r, facts


def _numbers(s: str) -> set[str]:
    return {n.lstrip("0") or "0" for n in re.findall(r"\d+(?:\.\d+)?", s)}


def verify(lines: list[str], facts: dict) -> bool:
    """Every number in the summary must exist in the facts (blocks invented values)."""
    allowed = _numbers(json.dumps(facts))
    return all(_numbers(line) <= allowed for line in lines)


def template(facts: dict) -> list[str]:
    out = []
    if facts.get("age") is not None:
        out.append(f"{facts['age']}yo {facts.get('sex') or ''} — {facts['visit_type']}".strip())
    if facts.get("problems"):
        out.append("Dx: " + "; ".join(p["name"] for p in facts["problems"][:5] if p.get("name")))
    if "allergies" in facts:
        out.append("Allergies: " + ("; ".join(facts["allergies"]) or "NKDA"))
    if facts.get("medications"):
        out.append("Meds: " + "; ".join(facts["medications"][:5]))
    if facts.get("labs"):
        out.append("Labs: " + "; ".join(f"{l['test']} {l['value']}{l['unit'] or ''} ({l['date']})" for l in facts["labs"][:5]))
    if facts.get("recent_visits"):
        out.append("Recent: " + "; ".join(facts["recent_visits"][:3]))
    return out


def summarize(facts: dict, r: dict, rules: dict) -> tuple[list[str], str]:
    prompt = (f"Visit type: {facts['visit_type']}\nFocus: {r.get('focus', 'general')}\n"
              f"Max {rules['max_lines']} lines.\nFacts:\n{json.dumps(facts, default=str)}")
    try:
        out = llm.structured(system=SYSTEM, content=[llm.text_block(prompt)], schema=SUMMARY_SCHEMA, max_tokens=800)
        lines = [l.strip(" -•") for l in out["lines"] if l.strip()][: rules["max_lines"]]
        if lines and verify(lines, facts):
            return lines, "claude"
        log.warning("summary failed number check; using template")
    except Exception:
        log.exception("Claude summary failed; using template")
    return template(facts), "template"


def run(api: DrChrono, db: DB, day: str | None = None) -> dict:
    """Write history for every appointment on `day` (default: today)."""
    rules = load_rules()
    day = day or date.today().isoformat()
    done = {"claude": 0, "template": 0, "error": 0}
    for appt in api.appointments_on(day):
        try:
            _, r, facts = gather(api, appt, rules)
            lines, how = summarize(facts, r, rules)
            body = "\n".join(lines)[: rules["max_chars"]] + f"\n(auto-history {datetime.now():%m/%d %H:%M})"
            fresh = api.get(f"/api/appointments/{appt['id']}")  # re-read to avoid clobbering staff edits
            api.write(AGENT, "PATCH", f"/api/appointments/{appt['id']}",
                      {"notes": upsert_section(fresh.get("notes"), TAG, body)})
            done[how] += 1
        except Exception:
            log.exception("appointment %s failed", appt.get("id"))
            done["error"] += 1
    return {"day": day, **done}
