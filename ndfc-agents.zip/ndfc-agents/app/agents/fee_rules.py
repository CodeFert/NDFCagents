"""Deterministic fee-schedule decisions — encodes the billing walkthrough (10/07/2026 videos).

Pure functions only: no DrChrono, no Claude. Inputs are
  * `appt`  — one appointment: {id, time "HH:MM", reason, profile, notes, virtual, office}
  * `case`  — per-patient facts produced by the case reader (see CASE_FIELDS in fee_schedule.py)
  * `prices`, `rules` — config/price_list.yaml and config/fee_schedule_rules.yaml
Output is a `Determination` whose `status` text matches what billing writes in the Status column.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

DASHES = "– – – –"

# Lab names that appear in appointment notes and are NOT run in NDFC's own lab.
SEND_OUT_LABS = {"AMH", "CBC", "GCS", "HIV", "RPR", "HEPB", "HEPC", "HBSAG", "RUBELLA", "VARICELLA",
                 "ABO", "ABO/RH", "CARRIER", "KARYOTYPE", "A1C", "CMP", "CF", "SMA", "T4FREE", "INSULIN",
                 "TESTOSTERONE", "DHEA", "17OHP", "PATHOLOGY"}


@dataclass
class Item:
    label: str
    amount: float


@dataclass
class Determination:
    outcome: str                      # NO_COST | SUB_INS | SUB_INS_3RD | COPAY | SELF_PAY | CYCLE_DUE | ESTIMATE_DUE | SEE_ABOVE | NEEDS_REVIEW
    status: str                       # text for the Status column
    items: list[Item] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    boxes: set[str] = field(default_factory=set)   # red (consent) / green (price sheet) / blue (new patient)
    force_review: bool = False
    category: str | None = None

    @property
    def amount_due(self) -> float:
        return round(sum(i.amount for i in self.items), 2)

    def to_dict(self) -> dict:
        return {"outcome": self.outcome, "status": self.status, "amount_due": self.amount_due,
                "items": [{"label": i.label, "amount": i.amount} for i in self.items],
                "reasons": self.reasons, "boxes": sorted(self.boxes), "force_review": self.force_review,
                "category": self.category}


TREATMENT_ROW_CATS = {"ivf_tracking", "iui_tracking", "fet_lining", "down_regulation", "retrieval", "transfer",
                      "insemination"}


# ------------------------------------------------------------------ helpers
def money(x: float) -> str:
    return f"${x:,.0f}" if abs(x - round(x)) < 0.005 else f"${x:,.2f}"


def items_text(items: list[Item], prefix: str = "", suffix: str = "") -> str:
    body = ", ".join(f"{i.label} {money(i.amount)}" for i in items)
    if len(items) > 1:
        body += f" - total {money(sum(i.amount for i in items))}"
    return f"{prefix}{body}{suffix}".strip()


def categorize(appt: dict, rules: dict) -> str | None:
    text = f"{appt.get('reason') or ''} | {appt.get('profile') or ''}"
    for vc in rules["visit_categories"]:
        if re.search(vc["match"], text, re.I):
            return vc["category"]
    return None


def lab_tokens(notes: str | None) -> list[str]:
    """Upper-case lab-ish tokens from appointment notes ('IVF E2...HSMA' -> ['IVF','E2','HSMA'])."""
    text = (notes or "").upper().replace("VIT D", "VIT_D").replace("VITAMIN D", "VIT_D").replace("ID LABS", "ID_LABS")
    toks = re.findall(r"[A-Z0-9_/]+", text.split("..")[0] if ".." in text else text)
    return [t.replace("VIT_D", "VIT D") for t in toks]


def split_labs(notes: str | None, prices: dict) -> tuple[list[str], bool, bool]:
    """Return (in_house_labs, has_send_out, has_id_labs)."""
    in_house_set = {x.upper() for x in prices.get("in_house_labs", [])}
    toks = lab_tokens(notes)
    in_house = [t for t in toks if t in in_house_set]
    id_labs = "ID_LABS" in toks
    send_out = id_labs or any(t in SEND_OUT_LABS for t in toks)
    return list(dict.fromkeys(in_house)), send_out, id_labs


def resolve_tier(case: dict) -> tuple[str | None, bool]:
    """Return (tier, no_insurance_question)."""
    if case.get("not_contracted"):
        return "cash", False
    tier = case.get("coverage_tier")
    if tier in (None, "unknown"):
        if case.get("insurance_on_file") is False:
            return "cash", True          # "No Ins?" — checked chart, spouse, insurance card; nothing found
        return None, False
    return tier, False


def ivf_expected(case: dict, prices: dict) -> list[Item]:
    p = prices["ivf"]
    items = [Item("IVF", p["cycle"]), Item("Anes", p["anesthesia"])]
    if case.get("consent_icsi") is True:
        items.append(Item("ICSI", p["icsi"]))
    pgt = case.get("consent_pgt")
    pgt_still_covered = case.get("pgt_a_paid_within_year") is True
    if pgt == "pgt_a" and not pgt_still_covered:
        items += [Item("Biopsy", p["pgt_a_biopsy"]), Item("PGT-A", p["pgt_a_testing"])]
    elif pgt in ("pgt_m", "pgt_sr"):
        items.append(Item("Biopsy", p["pgt_other_biopsy"]))
    if case.get("consent_embryo_glue") is True:
        items.append(Item("Glue", p["embryo_glue"]))
    return items


def _copay_or_sub_ins(case: dict, appt: dict, cat: str, prices: dict, reasons: list[str]) -> Determination:
    if cat == "blood_draw":
        _, send_out, _ = split_labs(appt.get("notes"), prices)
        return (Determination("SUB_INS_3RD", "Sub Ins & 3rd Party", reasons=reasons + ["send-out labs on order"])
                if send_out else Determination("SUB_INS", "Sub Ins", reasons=reasons))
    copay = case.get("copay")
    call = "Call to collect " if appt.get("virtual") else ""
    if copay is None:
        return Determination("COPAY", f"{call}Copay (amount not in chart)".strip(),
                             reasons=reasons + ["copay amount not found in coverage flag"], force_review=True)
    if copay <= 0:
        return Determination("SUB_INS", "Sub Ins", reasons=reasons + ["no copay"])
    return Determination("COPAY", f"{call}Copay {money(copay)}", [Item("Copay", copay)], reasons)


def _self_pay_items(cat: str, appt: dict, prices: dict) -> list[Item] | None:
    d, c = prices["diagnostic"], prices["consult"]
    simple = {"new_consult": ("NP consult", c["new_patient"]), "follow_up": ("F/U consult", c["follow_up"]),
              "semen_analysis": ("SA", d["semen_analysis"]), "shg": ("SHG", d["shg"]), "hsg": ("HSG", d["hsg"]),
              "cyst_check": ("US", d["ultrasound"]), "baseline_us": ("US", d["ultrasound"]),
              "early_pregnancy": ("US", d["ultrasound"]), "ocp_start": ("US", d["ultrasound"])}
    if cat in simple:
        label, amt = simple[cat]
        return [Item(label, amt)] if amt else None
    if cat == "blood_draw":
        in_house, _, id_labs = split_labs(appt.get("notes"), prices)
        items = []
        if in_house:
            items.append(Item(f"Labs ({', '.join(in_house)})", d["in_house_lab"] * len(in_house)))
        if id_labs:
            items.append(Item("ID labs", d["id_labs"]))
        return items or None
    if cat == "endometrial_biopsy":
        items = [Item("Mock cycle", d["endometrial_biopsy_mock_cycle"])]
        if re.search(r"receptiva|labcorp|pathology|send", appt.get("notes") or "", re.I):
            items.append(Item("Biopsy send-out", d["endometrial_biopsy_send_out"]))
        return items
    return None


# ------------------------------------------------------------------ main decision
def decide(appt: dict, case: dict, prices: dict, rules: dict) -> Determination:
    cat = categorize(appt, rules)
    det = _decide(appt, case, prices, rules, cat)
    det.category = cat

    # row markers
    if case.get("new_patient") and not appt.get("virtual"):
        det.boxes.add("blue")
    if cat in rules.get("consent_required", []) and case.get("procedure_consent_signed") is False:
        det.boxes.add("red")
    if (cat in rules.get("price_sheet_required", []) and case.get("treatment_self_pay")
            and case.get("price_sheet_signed") is False):
        det.boxes.add("green")

    # safety rules: always to a person
    ar = rules.get("always_review_if", {})
    bal = case.get("balance_due") or 0
    if bal > 0 and det.outcome not in ("NO_COST",) and ar.get("balance_due", True):
        det.force_review = True
        det.reasons.append(f"past-due balance {money(bal)} — verify before adding")
    elif bal > 0:
        det.force_review = True
        det.reasons.append(f"past-due balance {money(bal)} on account")
    if case.get("uncertain") and ar.get("low_confidence", True):
        det.force_review = True
        det.reasons += [f"unclear: {u}" for u in case["uncertain"][:3]]
    if case.get("authorization_status") in ("expired", "denied", "mismatch") and ar.get("authorization_problem", True) \
            and det.outcome in ("SUB_INS", "COPAY", "SUB_INS_3RD"):
        det.force_review = True
        det.reasons.append(f"authorization {case['authorization_status']} — check before submitting")
    return det


def _decide(appt: dict, case: dict, prices: dict, rules: dict, cat: str | None) -> Determination:
    if cat is None:
        return Determination("NEEDS_REVIEW", "Billing to review", reasons=["visit type not recognized"], force_review=True)
    if cat in rules["no_cost_categories"]:
        return Determination("NO_COST", DASHES, reasons=[cat.replace("_", " ")])
    if (appt.get("time") or "99:99") <= rules.get("complimentary_before", "00:00") \
            and cat in rules.get("complimentary_early_categories", []):
        return Determination("NO_COST", DASHES, reasons=["complimentary early scan"])

    tier, no_ins = resolve_tier(case)
    if tier is None:
        return Determination("NEEDS_REVIEW", "Billing to review", reasons=["coverage could not be determined"],
                             force_review=True)
    reasons = [f"coverage: {tier}"]
    treatment_cats = {c for cats in rules["package_categories"].values() for c in cats}

    # ---------------------------------------------------------------- treatment visits
    if cat in treatment_cats and cat not in rules.get("outside_package", []):
        covered = (tier == "specialty" or cat in rules["coverage_allows"].get(tier, [])) and not (
            case.get("military") and cat in rules.get("military_self_pay", []))
        if cat == "sperm_prep" and tier != "specialty" and not case.get("treatment_self_pay"):
            return Determination("NEEDS_REVIEW", "Billing to review",
                                 reasons=reasons + ["sperm prep on insured cycle depends on spouse's coverage"],
                                 force_review=True)
        if covered and not case.get("treatment_self_pay"):
            if tier == "specialty":
                return Determination("SUB_INS", "Sub Ins", reasons=reasons + [f"{case.get('specialty_program') or 'specialty'} program — patient pays program directly"])
            est, paid = case.get("estimate_amount"), case.get("estimate_paid")
            if est and paid is False:
                t = (case.get("treatment_type") or "Tx").upper().replace("DONOR_", "")
                return Determination("ESTIMATE_DUE", f"{t} Est {money(est)} due", [Item(f"{t} Est", est)],
                                     reasons + ["insurance estimate not paid — due before transfer/retrieval"])
            return _copay_or_sub_ins(case, appt, cat, prices, reasons + ["treatment covered by insurance"])
        if case.get("military") and cat == "insemination":
            if case.get("insemination_paid"):
                return Determination("NO_COST", DASHES, reasons=reasons + ["military: IUI fee already paid"])
            amt = prices["iui"]["insemination"]
            return Determination("CYCLE_DUE", f"IUI {money(amt)} due before insemination", [Item("IUI", amt)],
                                 reasons + ["military coverage: insemination is self-pay"])
        if case.get("military") and cat == "iui_tracking":
            return _copay_or_sub_ins(case, appt, cat, prices, reasons + ["military: diagnostic ultrasound to insurance"])
        return _self_pay_treatment(appt, case, prices, rules, cat, reasons)

    # ---------------------------------------------------------------- everything else
    if cat == "follow_up" and case.get("comp_followup_eligible"):
        return Determination("NO_COST", DASHES, reasons=reasons + ["complimentary follow-up after cycle"])
    if tier != "cash" and (tier == "specialty" or cat in rules["coverage_allows"].get(tier, [])):
        return _copay_or_sub_ins(case, appt, cat, prices, reasons)
    items = _self_pay_items(cat, appt, prices)
    if not items:
        return Determination("NEEDS_REVIEW", "Billing to review",
                             reasons=reasons + [f"no self-pay price set for {cat}"], force_review=True)
    prefix = ("Call to collect " if appt.get("virtual") else "") + ("No Ins? " if no_ins else "")
    suffix = ""
    if cat == "blood_draw" and split_labs(appt.get("notes"), prices)[1]:
        suffix = " + 3rd party bills send-outs"
    return Determination("SELF_PAY", items_text(items, prefix, suffix), items,
                         reasons + ["not covered — self-pay"], force_review=no_ins)


def _self_pay_treatment(appt, case, prices, rules, cat, reasons) -> Determination:
    ttype = case.get("treatment_type") or "unclear"
    reasons = reasons + [f"self-pay {ttype} treatment"]

    # donor / COMP FET packages: unlimited transfers until pregnancy
    if case.get("unlimited_transfer_package") and cat in ("fet_lining", "transfer"):
        if case.get("pregnancy_achieved"):
            return Determination("NEEDS_REVIEW", "Billing to review",
                                 reasons=reasons + ["unlimited-transfer package but pregnancy already achieved"],
                                 force_review=True)
        return Determination("NO_COST", DASHES, reasons=reasons + ["unlimited-transfer package"])

    if ttype in ("ivf", "fet") and cat in ("fet_lining", "transfer"):
        used = case.get("transfers_since_retrieval")
        if case.get("package_paid") and used is not None and used >= rules.get("complimentary_transfers_with_ivf", 1):
            return Determination("NEEDS_REVIEW", "Billing to review",
                                 reasons=reasons + [f"{used} transfer(s) already used — FET is not in the package; price needed"],
                                 force_review=True)

    if ttype == "ivf":
        expected = ivf_expected(case, prices)
    elif ttype == "iui":
        expected = [Item("IUI", prices["iui"]["insemination"])]
    elif case.get("financial_overview_total"):
        expected = [Item(f"{ttype.upper()} cycle", case["financial_overview_total"])]
    else:
        return Determination("NEEDS_REVIEW", "Billing to review",
                             reasons=reasons + ["treatment type or cycle price unclear"], force_review=True)

    total = sum(i.amount for i in expected)
    paid = case.get("amount_paid_toward_cycle") or 0
    if case.get("package_paid") or paid >= total - 0.5:
        return Determination("NO_COST", DASHES, reasons=reasons + [f"package paid ({money(paid or total)})"])

    due = round(total - paid, 2)
    suffix = f" w/deposit {money(paid)} - due {money(due)}" if paid else " due"
    det = Determination("CYCLE_DUE", items_text(expected, "", suffix), [Item("Balance of cycle", due)],
                        reasons + [f"cycle total {money(total)}, paid {money(paid)}"])
    if case.get("loan_status") == "pending":
        det.status += " — loan not approved, cost due now"
        det.force_review = True
        det.reasons.append("lender (Future Family) approval pending in chart")
    if cat not in rules.get("payment_due_by", []):
        det.reasons.append("payment due before down-regulation / retrieval")
    return det


def combine_patient(dets: list[tuple[dict, Determination]], case: dict | None = None) -> None:
    """Per-patient clean-up, the way billing writes the sheet:
      * monitoring labs drawn the same day as a self-pay treatment visit follow that visit
        (in package -> dashes, cycle due -> 'see above');
      * money due is written once: self-pay items merge onto the first such row, later rows 'see above';
      * the blue new-patient box goes on the patient's first row only."""
    case = case or {}
    treat = next((d for _, d in dets if d.category in TREATMENT_ROW_CATS), None)
    if treat and case.get("treatment_self_pay"):
        for _, d in dets:
            if d.category == "blood_draw" and d.outcome in ("SUB_INS", "SUB_INS_3RD", "SELF_PAY"):
                if treat.outcome == "NO_COST":
                    d.outcome, d.status, d.items = "NO_COST", DASHES, []
                    d.reasons.append("cycle monitoring labs — part of package")
                elif treat.outcome == "CYCLE_DUE":
                    d.outcome, d.status, d.items = "SEE_ABOVE", "see above", []
    for _, d in dets[1:]:
        d.boxes.discard("blue")
    money_rows = [d for _, d in dets if d.outcome == "SELF_PAY" and d.items]
    if len(money_rows) < 2:
        return
    first = money_rows[0]
    merged = [i for d in money_rows for i in d.items]
    prefix = "No Ins? " if any(d.status.startswith(("No Ins?", "Call to collect No Ins?")) for d in money_rows) else ""
    first.items = merged
    first.status = items_text(merged, prefix)
    first.force_review = any(d.force_review for d in money_rows)
    for d in money_rows[1:]:
        d.outcome, d.status, d.items = "SEE_ABOVE", "see above", []
