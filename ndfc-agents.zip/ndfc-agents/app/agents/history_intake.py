"""Agent 3 — scanned Infertility History Form → discrete chart data (writes directly).

Safeguards (direct write does not mean unguarded):
  * Identity check: name + DOB read from the form must match the chart, or nothing is written.
  * Confidence gate: only items Claude marks at/above `min_confidence` are written;
    the rest go to a nurse review list with the page they came from.
  * De-duplication against existing problems / meds / allergies.
  * Idempotent: each document is processed once; every write is in the audit table.
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime, timedelta

import yaml

from .. import llm
from ..chart import Chart, custom_demographic_names
from ..db import DB
from ..drchrono import DrChrono
from ..settings import settings

log = logging.getLogger("history_intake")
AGENT = "history_intake"

CONF = {"type": "string", "enum": ["high", "medium", "low"]}


def _scalar(desc: str, typ="string") -> dict:
    return {"type": "object", "description": desc,
            "properties": {"value": {"type": [typ, "null"]}, "confidence": CONF, "page": {"type": "integer"}},
            "required": ["value", "confidence"]}


def _list(desc: str, item_props: dict) -> dict:
    first = next(iter(item_props))
    return {"type": "array", "description": desc,
            "items": {"type": "object", "properties": {**item_props, "confidence": CONF, "page": {"type": "integer"}},
                      "required": [first, "confidence"]}}


SCHEMA = {
    "type": "object",
    "properties": {
        "patient_name": _scalar("Patient full name as written"),
        "date_of_birth": _scalar("YYYY-MM-DD"),
        "gravida": _scalar("Total pregnancies", "integer"),
        "para": _scalar("Births after 20 weeks", "integer"),
        "term_births": _scalar("", "integer"),
        "preterm_births": _scalar("", "integer"),
        "miscarriages": _scalar("Miscarriages/abortions", "integer"),
        "ectopic_pregnancies": _scalar("", "integer"),
        "living_children": _scalar("", "integer"),
        "lmp": _scalar("Last menstrual period YYYY-MM-DD"),
        "cycle_length_days": _scalar("Typical cycle length in days, as written (e.g. '28' or '26-32')"),
        "cycles_regular": _scalar("'Yes' or 'No'"),
        "months_trying": _scalar("Months trying to conceive", "integer"),
        "tobacco": _scalar("Tobacco use as written"),
        "alcohol": _scalar("Alcohol use as written"),
        "partner_name": _scalar("Partner name"),
        "medical_history": _list("Medical conditions the patient marked YES or wrote in",
                                 {"name": {"type": "string"}, "icd10": {"type": ["string", "null"]}}),
        "surgical_history": _list("Surgeries with year if given", {"text": {"type": "string"}}),
        "medications": _list("Current medications", {"name": {"type": "string"}, "dose": {"type": ["string", "null"]},
                                                    "frequency": {"type": ["string", "null"]}}),
        "allergies": _list("Drug/other allergies", {"substance": {"type": "string"}, "reaction": {"type": ["string", "null"]}}),
        "nkda_checked": _scalar("True if 'no known drug allergies' is checked", "boolean"),
        "prior_fertility_treatment": _list("Prior fertility treatments (IUI, IVF, Clomid, letrozole...) with dates/outcomes",
                                           {"text": {"type": "string"}}),
        "family_history": _list("Family history entries", {"text": {"type": "string"}}),
        "unreadable_sections": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["patient_name", "date_of_birth", "medical_history", "medications", "allergies"],
}

SYSTEM = (
    "You abstract a scanned, handwritten/checkbox infertility history intake form into structured data. "
    "Rules: record only what the patient actually wrote or checked. A blank or unchecked item is null / omitted, "
    "never 'No' and never 'None'. Do not normalize drug names beyond correcting obvious spelling; keep doses as written. "
    "confidence = high only when the handwriting/checkmark is unambiguous; medium if you had to interpret; "
    "low if guessing. Give the 1-based page number for each item. List any illegible sections in unreadable_sections. "
    "ICD-10 codes only when the condition maps unambiguously to a single code; otherwise null."
)


def load_map() -> dict:
    return yaml.safe_load((settings.config_dir / "history_form_map.yaml").read_text())


def _ok(conf: str, minimum: str) -> bool:
    order = {"low": 0, "medium": 1, "high": 2}
    return order.get(conf, 0) >= order[minimum]


def _norm(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def identity_matches(extracted: dict, patient: dict) -> tuple[bool, str]:
    name = _norm(extracted["patient_name"].get("value"))
    first, last = _norm(patient.get("first_name")), _norm(patient.get("last_name"))
    dob_form = (extracted["date_of_birth"].get("value") or "")[:10]
    dob_chart = (patient.get("date_of_birth") or "")[:10]
    if not (first and last and first in name and last in name):
        return False, "name on form does not match chart"
    if dob_form != dob_chart:
        return False, f"DOB on form ({dob_form or 'blank'}) does not match chart"
    return True, ""


def plan_writes(extracted: dict, chart: Chart, fmap: dict, cd_names: dict[int, str]) -> tuple[list, list]:
    """Return (writes, review_items). Pure function apart from reading the chart."""
    pid, doc = chart.pid, settings.default_doctor_id
    minimum = fmap.get("min_confidence", "high")
    writes, review = [], []
    custom_updates: dict[str, str] = {}

    existing_problems = {_norm(p.get("name")) for p in chart.problems}
    existing_meds = {_norm((m.get("name") or "").split()[0]) for m in chart.medications if m.get("name")}
    existing_allergies = {_norm(a.get("description")) for a in chart.allergies}

    for key, target in fmap["targets"].items():
        val = extracted.get(key)
        if val is None:
            continue
        items = val if isinstance(val, list) else [val]
        for it in items:
            v = it.get("value", it)
            if v in (None, "", [], {}):
                continue
            if not _ok(it.get("confidence", "low"), minimum):
                review.append({"field": key, "item": {k: x for k, x in it.items() if k not in ("confidence",)},
                               "confidence": it.get("confidence"), "page": it.get("page")})
                continue
            if target == "problems":
                if _norm(it["name"]) in existing_problems:
                    continue
                body = {"patient": pid, "doctor": doc, "name": it["name"], "status": "active",
                        "notes": "From scanned history form"}
                if fmap.get("problems_with_icd10") and it.get("icd10") and re.fullmatch(r"[A-TV-Z]\d{2}(\.\w{1,4})?", it["icd10"]):
                    body["icd_code"] = it["icd10"]
                writes.append(("POST", "/api/problems", body))
            elif target == "medications":
                if _norm(it["name"].split()[0]) in existing_meds:
                    continue
                writes.append(("POST", "/api/medications", {
                    "patient": pid, "doctor": doc, "name": it["name"], "status": "active",
                    "dosage_quantity": it.get("dose") or "", "frequency": it.get("frequency") or "",
                    "notes": "Patient-reported on scanned history form"}))
            elif target == "allergies":
                if _norm(it["substance"]) in existing_allergies:
                    continue
                writes.append(("POST", "/api/allergies", {
                    "patient": pid, "doctor": doc, "description": it["substance"],
                    "reaction": it.get("reaction") or "", "status": "active",
                    "notes": "Patient-reported on scanned history form"}))
            elif target.startswith("custom:"):
                field_name = target.split(":", 1)[1]
                text = str(it.get("text") or v)
                custom_updates[field_name] = (custom_updates[field_name] + "; " + text) if field_name in custom_updates else text

    if custom_updates:
        by_name = {n: i for i, n in cd_names.items()}
        missing = [n for n in custom_updates if n not in by_name]
        for n in missing:
            review.append({"field": n, "item": custom_updates.pop(n), "confidence": "n/a",
                           "page": None, "why": "custom demographic field does not exist in DrChrono"})
        if custom_updates:
            # PATCH with the full merged list so existing custom fields are not wiped.
            current = {cd["field_type"]: cd.get("value") for cd in chart.patient.get("custom_demographics") or []}
            for n, v in custom_updates.items():
                have = current.get(by_name[n])
                if not have:  # never overwrite a value staff already entered
                    current[by_name[n]] = v
                elif str(have).strip().lower() != v.strip().lower():
                    review.append({"field": n, "item": v, "confidence": "n/a", "page": None,
                                   "why": f"chart already has '{current[by_name[n]]}'"})
            writes.append(("PATCH", f"/api/patients/{pid}",
                           {"custom_demographics": [{"field_type": k, "value": v} for k, v in current.items()]}))
    return writes, review


def process_document(api: DrChrono, db: DB, document: dict, fmap: dict) -> dict:
    pid = document["patient"]
    chart = Chart(api, pid)
    pdf = api.download(document["document"])
    extracted = llm.structured(
        system=SYSTEM,
        content=[llm.pdf_block(pdf), llm.text_block("Abstract this intake form.")],
        schema=SCHEMA, model=settings.claude_model_extraction, max_tokens=8000,
    )
    if fmap.get("require_identity_match", True):
        ok, why = identity_matches(extracted, chart.patient)
        if not ok:
            db.enqueue(AGENT, document["id"], pid, date.today().isoformat(),
                       {"outcome": "IDENTITY_MISMATCH", "reason": why, "document": document["id"]}, [])
            return {"outcome": "identity_mismatch", "why": why}

    writes, review = plan_writes(extracted, chart, fmap, custom_demographic_names(api))
    for method, path, body in writes:
        api.write(AGENT, method, path, body)
    if review or extracted.get("unreadable_sections"):
        db.enqueue(AGENT, document["id"], pid, date.today().isoformat(),
                   {"outcome": "NEEDS_NURSE_REVIEW", "items": review,
                    "unreadable": extracted.get("unreadable_sections", []), "document": document["id"]}, [])
    api.write(AGENT, "PATCH", f"/api/documents/{document['id']}",
              {"description": f"{document.get('description', '')} [abstracted {datetime.now():%m/%d/%y}]"[:250]})
    return {"outcome": "written", "writes": len(writes), "for_review": len(review)}


def run(api: DrChrono, db: DB) -> dict:
    fmap = load_map()
    since = (date.today() - timedelta(days=fmap.get("lookback_days", 3))).isoformat()
    pats = [p.lower() for p in fmap["document_match"]]
    counts: dict[str, int] = {}
    for d in api.documents(since=since):
        desc = (d.get("description") or "").lower()
        if not any(p in desc for p in pats) or "[abstracted" in desc or db.is_processed(d["id"]):
            continue
        try:
            res = process_document(api, db, d, fmap)
        except Exception as e:
            log.exception("document %s failed", d["id"])
            res = {"outcome": "error", "why": str(e)[:200]}
        if res["outcome"] != "error" and not settings.dry_run:
            db.mark_processed(d["id"], d.get("patient"), res["outcome"], res)
        counts[res["outcome"]] = counts.get(res["outcome"], 0) + 1
    return counts
