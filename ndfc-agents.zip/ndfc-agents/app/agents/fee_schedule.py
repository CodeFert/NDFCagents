"""Agent 1 — nightly fee schedule, modeled on billing's 10/07/2026 walkthrough videos.

Per office, per patient on tomorrow's schedule:
  1. Gather what billing looks at: appointment(s), patient flags (coverage / billing memo / cash pay /
     authorization / balance due), chart photo, visit history, patient payments, documents.
  2. Claude reads each relevant PDF once (Financial Overview & Price Sheet, IVF/FET consents, embryology
     report) -> structured facts, cached by document id.
  3. Claude reads the whole case (flags + history + payments + document facts) -> per-patient facts,
     each backed by a quote. It never prices anything.
  4. fee_rules.decide() prices each appointment from config/price_list.yaml + fee_schedule_rules.yaml.
  5. review mode -> billing queue;  auto -> [[NDFC-PAYMENT]] in appointment notes.
  6. A day-sheet PDF per office (Time | Patient | Reason | Appt. Notes | Status) like the one billing makes.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import date, datetime, timedelta

import yaml

from .. import llm
from ..chart import Chart, profile_names
from ..db import DB
from ..drchrono import DrChrono, DrChronoError
from ..notes import upsert_section
from ..settings import settings
from . import fee_rules

log = logging.getLogger("fee_schedule")
AGENT = "fee_schedule"
TAG = "NDFC-PAYMENT"
HISTORY_DAYS = 550

# ------------------------------------------------------------------ document facts (cached per doc)
DOC_KINDS = {
    "price_sheet": r"price ?sheet|\bPFR\b|financial overview|financial responsibility|estimate",
    "ivf_consent": r"ivf.*consent|consents?.*ivf",
    "fet_consent": r"fet.*consent|consent.*fet",
    "embryo_report": r"fet report|embryolog|embryo (report|pics)|ivf report|pgt report",
}
NUM = {"type": ["number", "null"]}
DOC_SCHEMA = {
    "type": "object",
    "properties": {
        "doc_kind": {"type": "string", "enum": ["financial_overview", "price_sheet", "ivf_consent", "fet_consent",
                                                 "embryology_report", "other"]},
        "signed_by_patient": {"type": ["boolean", "null"]},
        "signed_date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
        "coverage_tier": {"type": ["string", "null"],
                          "enum": ["cash", "medical", "diagnostic", "dx_iui", "dx_iui_ivf", "specialty", None],
                          "description": "Which coverage box is marked/highlighted on a Financial Overview"},
        "copay": NUM, "deductible": NUM, "coinsurance": {"type": ["string", "null"]}, "lifetime_max": NUM,
        "authorization": {"type": ["string", "null"], "description": "e.g. 'denied', 'approved', 'obtained at appropriate time'"},
        "self_pay_items": {"type": "array", "items": {"type": "object", "properties": {
            "label": {"type": "string"}, "amount": {"type": "number"}}, "required": ["label", "amount"]}},
        "self_pay_total": NUM,
        "insurance_estimate": {**NUM, "description": "Patient-responsibility estimate for an insured cycle"},
        "cycle_type": {"type": ["string", "null"], "description": "IVF, FET, IUI, donor FET..."},
        "icsi": {"type": ["boolean", "null"]},
        "pgt": {"type": ["string", "null"], "enum": ["none", "pgt_a", "pgt_m", "pgt_sr", None]},
        "embryo_glue": {"type": ["boolean", "null"]},
        "donor": {"type": ["string", "null"], "description": "none / donor eggs / donor sperm"},
        "embryos_frozen_remaining": NUM,
        "notes": {"type": ["string", "null"], "description": "Anything billing-relevant in one line"},
    },
    "required": ["doc_kind", "self_pay_items"],
}
DOC_SYSTEM = (
    "You read one document from a fertility clinic chart for the billing team. Report only what the document "
    "states or what is visibly checked/filled/highlighted. Unmarked or blank = null. Amounts exactly as written. "
    "On IVF consents, read the IVF Cycle Plan: ICSI yes/no, genetic testing yes/no and which (PGT-A/M/SR), "
    "embryo glue, donor. On a Financial Overview, report the highlighted coverage tier, copay/deductible/"
    "coinsurance/lifetime max, authorization status, and every self-pay line item with its amount."
)

# ------------------------------------------------------------------ case facts (per patient)
B = {"type": ["boolean", "null"]}
CASE_SCHEMA = {
    "type": "object",
    "properties": {
        "coverage_tier": {"type": "string", "enum": ["cash", "medical", "diagnostic", "dx_iui", "dx_iui_ivf", "specialty", "unknown"]},
        "specialty_program": {"type": ["string", "null"], "description": "Progyny, Kindbody, GEHA (Progyny)..."},
        "not_contracted": {"type": "boolean", "description": "Insurance NDFC is not contracted with (e.g. AHCCCS) / flag says Cash Pay"},
        "military": {"type": "boolean", "description": "Tricare / CHAMPVA / military coverage"},
        "insurance_on_file": {"type": "boolean", "description": "Any insurance for this patient OR on the spouse's chart/card"},
        "copay": {**NUM, "description": "Copay from the coverage flag; 0 if flag says 'no copay'; null if not stated"},
        "treatment_type": {"type": ["string", "null"], "enum": ["ivf", "fet", "donor_fet", "iui", "none", "unclear", None]},
        "treatment_self_pay": B,
        "cycle_start_date": {"type": ["string", "null"]},
        "cycle_payment_refs": {"type": "array", "items": {"type": "integer"},
                               "description": "Indexes (P#) of payments that were made toward the CURRENT treatment cycle"},
        "package_paid_explicit": {**B, "description": "True only if a memo/note explicitly says the package/cycle is paid in full"},
        "financial_overview_total": {**NUM, "description": "Self-pay total for the current cycle from the Financial Overview, if not IVF"},
        "estimate_amount": {**NUM, "description": "Insured cycle estimate the patient must pay"},
        "estimate_paid": {**B, "description": "Estimate paid, or credit on account from estimates covers it"},
        "transfers_since_retrieval": {**NUM, "description": "Completed transfers since the last retrieval (exclude tomorrow)"},
        "unlimited_transfer_package": {**B, "description": "COMP FET / donor cycle unlimited package"},
        "pregnancy_achieved": B,
        "consent_icsi": B, "consent_pgt": {"type": ["string", "null"], "enum": ["none", "pgt_a", "pgt_m", "pgt_sr", None]},
        "consent_embryo_glue": B,
        "pgt_a_paid_within_year": {**B, "description": "PGT-A already paid in a package less than a year ago"},
        "price_sheet_signed": B, "procedure_consent_signed": B,
        "insemination_paid": B,
        "loan_status": {"type": ["string", "null"], "enum": ["approved", "pending", "denied", "none", None],
                        "description": "Future Family or other lender, as shown in memo/notes"},
        "comp_followup_eligible": {**B, "description": "Completed an IUI/IVF/FET cycle recently and hasn't used the complimentary follow-up"},
        "balance_due": {**NUM, "description": "Past-due patient balance confirmed by payments/statements (not just a flag)"},
        "authorization_status": {"type": ["string", "null"], "enum": ["active", "expired", "denied", "mismatch", "not_needed", "unknown", None]},
        "uncertain": {"type": "array", "items": {"type": "string"},
                      "description": "Short notes on anything confusing (switched protocol, conflicting notes)"},
        "evidence": {"type": "array", "items": {"type": "object", "properties": {
            "source": {"type": "string"}, "quote": {"type": "string"}}, "required": ["source", "quote"]}},
    },
    "required": ["coverage_tier", "not_contracted", "military", "insurance_on_file", "cycle_payment_refs",
                 "uncertain", "evidence"],
}
CASE_SYSTEM = """You are the billing specialist preparing tomorrow's fee schedule at a fertility clinic.
You do NOT price anything — you report facts about this patient that the pricing rules need.

How billing reads a chart:
- Coverage comes from the patient FLAGS first: "Fertility Coverage (Dx, IUI, IVF)" = dx_iui_ivf; "(Dx, IUI)" = dx_iui;
  "Diagnostic Coverage Only (No Fert Tx)" = diagnostic; "Medical only" = medical; "Cash Pay (No Insurance)" or a
  plan NDFC is not contracted with (AHCCCS) = cash + not_contracted. Progyny, Kindbody, or "GEHA - Progyny" = specialty.
  If a flag says fertility coverage but then "cash pay", the patient is cash. A Financial Overview with
  "Authorization Denied" for treatment means treatment is self-pay.
- Copay is in the coverage flag text ("no copay" = 0, "copay 50" = 50).
- A diagnostic-only patient doing IVF/IUI is self-pay for the treatment (treatment_self_pay = true).
- IVF package: monitoring, retrieval and ONE complimentary transfer; PGT-A covered for 1 year. Donor / "COMP FET
  (Donor Cycle - unlimited)" = unlimited transfers until pregnancy. Count completed transfers after the last retrieval.
- Decide which patient payments (P#) went toward the current cycle by date and amount; list their numbers.
- Treat a "Balance Due" flag as unverified; report balance_due only if payments/statement data show a real past-due amount.
- If the patient has no insurance on file, check the spouse info provided; insurance_on_file=false only if neither has any.
- When the picture is genuinely unclear (protocol switched, notes conflict), say so in `uncertain` rather than guessing.
Quote the exact flag/memo/note text behind every important fact in `evidence`."""


def load_rules() -> dict:
    return yaml.safe_load((settings.config_dir / "fee_schedule_rules.yaml").read_text())


def load_prices() -> dict:
    return yaml.safe_load((settings.config_dir / "price_list.yaml").read_text())


# ------------------------------------------------------------------ gathering
def _flag_lines(chart: Chart, flag_types: dict[int, str]) -> list[str]:
    out = []
    for f in chart.patient.get("patient_flags") or []:
        if isinstance(f, dict):
            if f.get("archived"):
                continue
            name = flag_types.get(f.get("flag_type"), "")
            text = " ".join(str(v) for k, v in f.items() if isinstance(v, str) and k not in ("created_at", "updated_at"))
            out.append(f"{name}: {text}".strip(": "))
        else:
            out.append(str(f))
    return out


def _doc_kind(d: dict) -> str | None:
    label = f"{d.get('description') or ''} {' '.join(str(t) for t in d.get('metatags') or [])}"
    for kind, rx in DOC_KINDS.items():
        if re.search(rx, label, re.I):
            return kind
    return None


def doc_facts(api: DrChrono, db: DB, d: dict) -> dict:
    cached = db.get_doc_facts(d["id"])
    if cached is not None:
        return cached
    pdf = api.download(d["document"])
    facts = llm.structured(system=DOC_SYSTEM, content=[llm.pdf_block(pdf), llm.text_block(
        f"Document title: {d.get('description')}")], schema=DOC_SCHEMA, model=settings.claude_model_extraction,
        max_tokens=2000)
    db.put_doc_facts(d["id"], facts)
    return facts


def gather_patient(api: DrChrono, db: DB, pid: int, appts: list[dict], profiles: dict, flag_types: dict) -> dict:
    chart = Chart(api, pid)
    since = (date.today() - timedelta(days=HISTORY_DAYS)).isoformat()
    history = sorted(chart.appointments(HISTORY_DAYS, 60), key=lambda a: a.get("scheduled_time") or "")
    payments = sorted(
        [p for p in chart.payments if (p.get("posted_date") or p.get("created_at") or "") >= since],
        key=lambda p: p.get("posted_date") or p.get("created_at") or "")
    docs = sorted(api.documents(patient=pid), key=lambda d: d.get("date") or "", reverse=True)

    latest: dict[str, dict] = {}
    for d in docs:
        k = _doc_kind(d)
        if k and k not in latest and (d.get("document") or "").strip():
            latest[k] = d
    facts = {}
    for k, d in latest.items():
        try:
            facts[f"{k} ({d.get('description')}, {d.get('date')})"] = doc_facts(api, db, d)
        except Exception as e:  # noqa: BLE001 — a bad PDF should not sink the patient
            log.warning("doc %s unreadable: %s", d.get("id"), e)

    try:
        balance = sum(float(li.get("balance_pt") or 0) for li in api.line_items(pid, since=since))
    except DrChronoError:
        balance = None
    try:
        auths = api.list("/api/insurance_authorizations", patient=pid)  # endpoint name confirmed by `probe`
    except DrChronoError:
        auths = None

    pt = chart.patient
    ins = pt.get("primary_insurance") or {}
    return {
        "patient_id": pid,
        "name": f"{pt.get('first_name', '')} {pt.get('last_name', '')}".strip(),
        "new_patient": not pt.get("patient_photo"),
        "flags": _flag_lines(chart, flag_types),
        "primary_insurance": ins.get("insurance_payer_name") or ins.get("insurance_company"),
        "secondary_insurance": (pt.get("secondary_insurance") or {}).get("insurance_payer_name"),
        "tomorrow": [{"time": _hhmm(a), "visit": _visit(a, profiles), "notes": a.get("notes")} for a in appts],
        "history": [{"date": (a.get("scheduled_time") or "")[:10], "visit": _visit(a, profiles),
                     "status": a.get("status"), "notes": (a.get("notes") or "")[:160]} for a in history],
        "payments": [{"n": i, "date": (p.get("posted_date") or p.get("created_at") or "")[:10],
                      "amount": float(p.get("amount") or 0), "method": p.get("payment_method"),
                      "note": p.get("notes") or ""} for i, p in enumerate(payments)],
        "documents": [f"{(d.get('date') or '')[:10]} {d.get('description')} [{', '.join(map(str, d.get('metatags') or []))}]"
                      for d in docs[:40]],
        "document_facts": facts,
        "line_item_balance": balance,
        "authorizations": auths,
    }


def _hhmm(a: dict) -> str:
    return (a.get("scheduled_time") or "T00:00")[11:16]


def _visit(a: dict, profiles: dict) -> str:
    return f"{a.get('reason') or ''} | {profiles.get(a.get('profile'), '')}".strip(" |")


def read_case(gathered: dict) -> dict:
    # Names/ids are not needed for the billing facts, so they are not sent.
    payload = {k: v for k, v in gathered.items() if k not in ("patient_id", "name")}
    out = llm.structured(system=CASE_SYSTEM, content=[llm.text_block(json.dumps(payload, default=str))],
                         schema=CASE_SCHEMA, max_tokens=3000)
    # Arithmetic stays in code: sum the payments Claude attributed to this cycle.
    pays = {p["n"]: p["amount"] for p in gathered["payments"]}
    out["amount_paid_toward_cycle"] = round(sum(pays.get(i, 0) for i in out.get("cycle_payment_refs") or []), 2)
    out["package_paid"] = bool(out.get("package_paid_explicit"))
    out["new_patient"] = gathered["new_patient"]
    return out


# ------------------------------------------------------------------ run
def appointment_view(a: dict, profiles: dict, office_names: dict) -> dict:
    reason, notes = a.get("reason") or "", a.get("notes") or ""
    return {"id": a["id"], "patient": a["patient"], "time": _hhmm(a), "reason": reason,
            "profile": profiles.get(a.get("profile"), ""), "notes": notes,
            "virtual": bool(a.get("is_virtual")) or bool(re.search(r"telemed|video visit|tele-?health", f"{reason} {notes}", re.I)),
            "office": office_names.get(a.get("office"), str(a.get("office")))}


def run(api: DrChrono, db: DB, day: str | None = None) -> dict:
    rules, prices = load_rules(), load_prices()
    day = day or (date.today() + timedelta(days=1)).isoformat()
    profiles = profile_names(api)
    flag_types = {f["id"]: f["name"] for f in _safe_list(api, "/api/patient_flag_types")}
    office_names = {o["id"]: o["name"] for o in _safe_list(api, "/api/offices")}
    patient_names = {}

    appts = [appointment_view(a, profiles, office_names) for a in api.appointments_on(day)]
    by_patient: dict[int, list[dict]] = {}
    for a in sorted(appts, key=lambda x: x["time"]):
        by_patient.setdefault(a["patient"], []).append(a)

    counts: dict[str, int] = {}
    rows = []
    for pid, pappts in by_patient.items():
        try:
            g = gather_patient(api, db, pid, pappts, profiles, flag_types)
            patient_names[pid] = g["name"]
            case = read_case(g)
            dets = [(a, fee_rules.decide(a, case, prices, rules)) for a in pappts]
            fee_rules.combine_patient(dets, case)
        except Exception:
            log.exception("patient %s failed", pid)
            dets = [(a, fee_rules.Determination("NEEDS_REVIEW", "Billing to review",
                                                reasons=["agent error — see logs"], force_review=True)) for a in pappts]
            case = {"evidence": []}
        for a, det in dets:
            counts[det.outcome] = counts.get(det.outcome, 0) + 1
            proposal = {**det.to_dict(), "visit": f"{a['reason']}", "time": a["time"], "office": a["office"],
                        "patient_name": patient_names.get(pid, ""), "appt_notes": a["notes"],
                        "note": note_text(det.status, det.reasons)}
            rows.append((a, proposal))
            auto = settings.payment_mode == "auto" and not det.force_review and det.outcome != "NEEDS_REVIEW"
            if auto:
                post(api, a["id"], proposal["note"])
                db.enqueue(AGENT, a["id"], pid, day, proposal, case.get("evidence", []))
                db.decide_by_appt(AGENT, a["id"], "posted", {"status": det.status, "boxes": det.to_dict()["boxes"]}, "agent")
            else:
                db.enqueue(AGENT, a["id"], pid, day, proposal, case.get("evidence", []))
    pdfs = build_pdfs(db, day, rules)
    return {"day": day, "appointments": len(appts), "pdfs": [x.name for x in pdfs], **counts}


def build_pdfs(db: DB, day: str, rules: dict | None = None):
    from .fee_pdf import build_day
    rules = rules or load_rules()
    return build_day(db, AGENT, day, rules.get("offices", []), settings.fee_pdf_dir)


def _safe_list(api: DrChrono, path: str) -> list[dict]:
    try:
        return api.list(path)
    except DrChronoError as e:
        log.warning("%s unavailable: %s", path, e)
        return []


def note_text(status: str, reasons: list[str]) -> str:
    return f"Fee: {status}\nBasis: " + "; ".join(reasons[:3]) + f"\n(agent {datetime.now():%m/%d %H:%M})"


def post(api: DrChrono, appointment_id: int, note: str) -> None:
    appt = api.get(f"/api/appointments/{appointment_id}")
    api.write(AGENT, "PATCH", f"/api/appointments/{appointment_id}",
              {"notes": upsert_section(appt.get("notes"), TAG, note)})
