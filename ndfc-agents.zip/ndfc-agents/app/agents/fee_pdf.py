"""Builds the per-office fee schedule PDF billing currently makes by hand in Preview.

Same columns as DrChrono's printer-friendly appointment list (Time | Patient | Reason | Appt. Notes |
Status), with the Status filled in purple bold, and the colored boxes the front desk relies on:
  red   = patient must sign a consent      green = must sign the price sheet
  blue  = new patient (photo, ID, insurance card, financial agreement, HIPAA)
"""
from __future__ import annotations

from datetime import date
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

PURPLE = colors.HexColor("#6a1b9a")
BOX = {"red": colors.HexColor("#d32f2f"), "green": colors.HexColor("#2e7d32"), "blue": colors.HexColor("#1565c0")}

cell = ParagraphStyle("cell", fontName="Helvetica", fontSize=7.5, leading=9)
status_style = ParagraphStyle("status", parent=cell, fontName="Helvetica-Bold", textColor=PURPLE, fontSize=8, leading=9.5)
head = ParagraphStyle("head", fontName="Helvetica-Bold", fontSize=13, leading=16)
sub = ParagraphStyle("sub", fontName="Helvetica", fontSize=8, leading=10, textColor=colors.HexColor("#555555"))


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _fmt_time(hhmm: str) -> str:
    h, m = int(hhmm[:2]), hhmm[3:5]
    return f"{(h - 1) % 12 + 1}:{m} {'a.m.' if h < 12 else 'p.m.'}"


def row_status(item: dict) -> tuple[str, list[str], bool]:
    """Final text/boxes for a queue item: reviewer's version wins, else the agent's proposal."""
    p, f = item["proposal"], item.get("final") or {}
    status = f.get("status") or p.get("status") or ""
    boxes = f.get("boxes", p.get("boxes", []))
    pending = item["status"] == "pending"
    return status, boxes, pending


def build_office_pdf(day: str, office: str, items: list[dict], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in office)
    path = out_dir / f"Fee_Schedule_{day}_{safe}.pdf"
    d = date.fromisoformat(day)
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=0.4 * inch, rightMargin=0.4 * inch,
                            topMargin=0.45 * inch, bottomMargin=0.45 * inch,
                            title=f"Fee Schedule {d:%m/%d/%y} {office}")
    items = sorted(items, key=lambda i: (i["proposal"].get("time") or "", i["id"]))
    pending_n = sum(1 for i in items if i["status"] == "pending")
    story = [Paragraph(f"Fee Schedule — {_esc(office)} — {d:%A %m/%d/%Y}", head),
             Paragraph("Boxes: <font color='#d32f2f'><b>red</b></font> sign consent · "
                       "<font color='#2e7d32'><b>green</b></font> sign price sheet · "
                       "<font color='#1565c0'><b>blue</b></font> new patient (photo, ID, insurance card, financial agreement)"
                       + (f" · <b>{pending_n} not yet reviewed</b>" if pending_n else ""), sub),
             Spacer(1, 6)]

    data = [["Time", "Patient", "Reason", "Appt. Notes", "Status"]]
    styles = [("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eeeeee")),
              ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#999999")), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    for r, it in enumerate(items, start=1):
        p = it["proposal"]
        status, boxes, pending = row_status(it)
        data.append([Paragraph(_fmt_time(p.get("time") or "00:00"), cell),
                     Paragraph(_esc(p.get("patient_name") or f"#{it['patient_id']}"), cell),
                     Paragraph(_esc(p.get("visit") or ""), cell),
                     Paragraph(_esc(p.get("appt_notes") or ""), cell),
                     Paragraph(_esc(status) + (" <font color='#999999' size=6>(unreviewed)</font>" if pending else ""),
                               status_style)])
        # boxes go around Patient + Reason, like billing draws them; extra colors nest inside
        spans = [((1, r), (2, r)), ((1, r), (1, r)), ((2, r), (2, r))]
        for color, (a, b) in zip(sorted(boxes), spans):
            styles.append(("BOX", a, b, 2 if a != b else 1.2, BOX.get(color, colors.black)))
    t = Table(data, colWidths=[0.6 * inch, 1.15 * inch, 1.45 * inch, 2.75 * inch, 1.75 * inch], repeatRows=1)
    t.setStyle(TableStyle(styles))
    story.append(t)
    doc.build(story)
    return path


def build_day(db, agent: str, day: str, offices_order: list[str], out_root: Path) -> list[Path]:
    items = db.day_items(agent, day)
    by_office: dict[str, list[dict]] = {}
    for it in items:
        by_office.setdefault(it["proposal"].get("office") or "Unknown", []).append(it)
    order = [o for o in offices_order if o in by_office] + sorted(o for o in by_office if o not in offices_order)
    return [build_office_pdf(day, o, by_office[o], out_root / day) for o in order]
