# NDFC DrChrono Agents

Three scheduled agents that read DrChrono through its API, use Claude where judgment over
unstructured input is needed, and write results back to the chart.

| # | Agent | When | Writes | Review |
|---|-------|------|--------|--------|
| 1 | **Fee schedule** — what to collect at each of tomorrow's visits | 1:15 am for tomorrow's visits | Per-office fee schedule PDF + `[[NDFC-PAYMENT]]` section in appointment notes | Billing approves each one (`PAYMENT_MODE=review`) until accuracy is proven, then `auto` |
| 2 | **Pertinent history** — rule-driven summary per visit type | 4:45 am and 11:45 am for today | `[[NDFC-HISTORY]]` section in appointment notes | None |
| 3 | **History form intake** — scanned Infertility History Form → discrete data | Every 15 min, clinic hours | Problems, medications, allergies, custom demographic fields | None for confident items; exceptions go to the nurse list |

Review page: `http://<gilbert-server>:8085` (LAN only, basic auth) — billing queue at `/`, nurse exceptions at `/intake`.

## How each agent decides

**Claude reads, rules decide.** Claude never decides what a patient owes or what goes in the chart on its own.

- **Fee schedule.** Built from billing's two walkthrough videos (10/07/2026). See "Fee schedule" below.
- **Pertinent history.** `config/pertinent_history_rules.yaml` defines, per visit type, which sections and lab
  groups to pull and how far back. Claude condenses those facts. If the summary contains any number that isn't
  in the pulled data, it's discarded and a plain template is written instead.
- **History form.** Picks up DrChrono documents whose description matches "Infertility History" (configurable).
  Claude reads the scanned PDF and returns each item with a confidence and page number. Before writing anything:
  name + DOB must match the chart; existing problems/meds/allergies are de-duplicated; existing custom field values
  are never overwritten; medium/low-confidence items go to the nurse list. The document description is stamped
  `[abstracted mm/dd/yy]`.

Both note-writing agents only replace their own fenced section, so staff text in the notes field is untouched.
Every write is logged in `data/agents.db` (`audit` table) with the payload and created record id.

## Fee schedule

Replaces the nightly manual process: print each office's appointment list from DrChrono, then open
each patient's flags, documents, payments and appointment history, and type the amount due into the Status column.

**What it reads, in billing's order:**
1. **Patient flags** — Fertility Coverage (Dx / IUI / IVF tier, copay, deductible), Diagnostic Coverage Only,
   Cash Pay (No Insurance), Billing Note/Memo (e.g. "IVF w/ PGT-A – Future Family CONFIRMED", "COMP FET (Donor Cycle – unlimited)"),
   Authorization, Balance Due, Spouse, specialty programs (Progyny, Kindbody, GEHA → Progyny).
2. **Documents** — Financial Overview & Price Sheet (coverage tier, self-pay items, insurance estimate), IVF/FET consents
   (ICSI, PGT-A/M/SR, embryo glue, donor), embryology/FET report (embryos remaining). Claude reads each PDF **once** and the
   facts are cached by document id.
3. **Patient payments** — Claude says which payments belong to the current cycle; code adds them up.
4. **Appointment history** — retrieval done? transfers since retrieval? recent cycle (comp follow-up)?
5. **Chart photo** — none means new patient → blue box.

**What it writes** (same wording as the hand-made sheet): `– – – –`, `Sub Ins`, `Sub Ins & 3rd Party`, `Copay $50`,
`Call to collect Copay $50` (telemedicine), `No Ins? SA $200, ID labs $250 - total $450`,
`IVF $6,500, Anes $500, Biopsy $1,200, PGT-A $2,000 w/deposit $500 - due $9,700`, `FET Est $2,294.24 due`, `see above`;
plus red (consent), green (price sheet) and blue (new patient) boxes. PDFs go to `FEE_PDF_DIR`, one per office in the
order West Valley → Vegas → Scottsdale → Gilbert, and can be rebuilt from the review page after edits.

**Rules live in YAML** — `config/price_list.yaml` (prices, in-house lab list) and `config/fee_schedule_rules.yaml`
(visit-type matching, what each coverage tier allows, package contents, boxes, review triggers). Claude never prices:
it reports facts with quotes, and `app/agents/fee_rules.py` does the math (`tests/test_fee_rules.py` has one test per case from the videos).

**Always goes to a person, even in auto mode:** past-due balance, unclear chart (switched protocols, conflicting notes),
expired/denied/mismatched authorization, lender approval pending, second transfer beyond the IVF package, unrecognized visit type.

**Not automated (no API access):** the Future Family provider portal, the "IVF Patients Cost" Numbers spreadsheet,
allocating payments / processing fees, and creating benefits-team tasks. The agent flags those situations for billing.

## Before going live

1. **New DrChrono API app** with these scopes (your current uploader app only has `patients:summary`):
   `user:read patients:read patients:write calendar:read calendar:write clinical:read clinical:write billing:read billing:patient-payment:read labs:read`
   Confirm exact scope names on the DrChrono API app page; edit `SCOPES` in `app/cli.py` if they differ.
2. **Claude API + PHI.** Confirm your Anthropic Enterprise BAA / zero-data-retention terms cover API traffic.
3. **Create custom demographic fields** in DrChrono that the rules reference (Treatment Package, Package Start
   Date, Package Paid, Copay Amount, Gravida, Para, …) — or change the names in the YAML to ones you already use.

## Setup on the Gilbert server

```bash
cp .env.example .env            # fill in keys; leave DRY_RUN=true
docker compose build
docker compose run --rm agents python -m app.cli auth      # one-time OAuth
docker compose run --rm agents python -m app.cli probe     # checks scopes, prints visit types + field names
```

Edit the YAML files in `config/` using the names `probe` prints (offices, visit types, flag names), confirm every `# CONFIRM` price in `price_list.yaml`, then test each agent by hand:

```bash
docker compose run --rm agents python -m app.cli fee --date 2026-10-12
docker compose run --rm agents python -m app.cli history --date 2026-10-12
docker compose run --rm agents python -m app.cli intake
docker compose up -d
```

With `DRY_RUN=true` nothing is written — the would-be writes are in the `audit` table (`dry_run=1`)
and fee-schedule proposals still appear on the review page, so billing can start grading accuracy immediately.

## Suggested rollout

1. Week 1 — `DRY_RUN=true`. Compare fee proposals to what the front desk actually collected; read the dry-run history notes.
2. Week 2 — `DRY_RUN=false`, one office (`OFFICE_IDS=`). History + intake live; fee schedule in review mode.
3. Fee schedule → `PAYMENT_MODE=auto` once the accepted-unchanged rate holds where you want it (e.g. ≥98% over 200+ visits).

## Field names to confirm with `probe`

The DrChrono field names below are used with fallbacks but should be checked against `probe` output:
lab result description/value/date fields, `patient_payments` amount/date/notes, `line_items.balance_pt`,
the `primary_insurance` payer field, and whether `PATCH /api/patients/{id}` with `custom_demographics`
merges or replaces (the agent sends the full merged list to be safe either way).

## Moving to AWS later

Same compose file on an EC2 instance in a HIPAA-eligible account with a BAA. Move `data/` (token + DB) with it,
use encrypted EBS, and keep the review page behind your VPN or an ALB with SSO instead of basic auth.

## Tests

`pip install -r requirements.txt pytest && pytest -q` — offline, no DrChrono or Claude calls.
